# GenUMI DataCap on Ubuntu

DataCap is a local browser interface for recording demonstrations with wrist-mounted cameras and VIVE Ultimate Trackers. An optional USB foot pedal marks episode boundaries without leaving the task. Run the following commands from the GenUMI source root.

## Try the interface

```sh
python3 -m datacap.webapp --dry-run --host 127.0.0.1 --port 8788
```

Open <http://127.0.0.1:8788/>. Choose a task and save folder, start capture, mark an episode, and end capture. Dry run writes simulated Tracker and event logs for checking the workflow. Camera media comes from a hardware session. Capture folders default to `~/InstaDataCap`.

## Install for real devices

On Ubuntu with BlueZ, install Python and HID dependencies, then install the Tracker software and the included device-specific udev rules.

```sh
sudo apt install bluez python3-dbus python3-gi python3-venv libhidapi-hidraw0 libhidapi-libusb0 ffmpeg
python3 -m venv datacap/.venv
source datacap/.venv/bin/activate
python -m pip install -e ./pyvut
bash datacap/tools/install_hardware_access.sh
cp datacap/config.example.json datacap/config.json
```

Pair the Trackers and make sure they have a usable map. Initial mapping may require VIVE Streaming Hub and SteamVR on Windows. For local Tracker configuration, copy `pyvut/wifi_info.example.json` to `~/.config/instadatacap/wifi_info.json` and fill in your own Tracker access point settings. Keep that file on the capture workstation.

In `datacap/config.json`, set `insta.addresses` and `insta.role_by_address` so the physical right and left X5s always map to `insta_right` and `insta_left`. Match your Trackers to `htc_right` and `htc_left` using `tracker.role_by_mac`. Use `DONGLE_USB` for the RF dongle or `TRACKER_USB` for direct USB where appropriate. The pedal rule matches USB VID:PID `0483:5750`. For another pedal, configure its stable input path and access permissions.

```sh
python -m datacap.webapp --config datacap/config.json --host 127.0.0.1 --port 8788
```

## Record X5 and Tracker demonstrations

1. Select **Bluetooth Control** and **Single arm · Right side** or **Dual arm · 2 Trackers**. Set the task and destination.
2. Click **Scan Bluetooth**, then **Connect cameras**. Confirm the intended camera roles and verify that each Tracker has a live 6DoF pose.
3. Click **Start capture**. After recording starts, rotate each rigid camera and Tracker assembly along several axes for 5–10 seconds with nonperiodic motion. Repeat every 10–15 minutes and just before ending capture. The motion gives the offline clock-alignment stage a signal to match.
4. Select **Episode capture** and mark the start and end of each demonstration. Use **SLAM calibration** markers if your selected trajectory workflow calls for them. The optional pedal starts a session with three short taps within 1.2 seconds, marks episodes with short taps and ends the session after a two-second hold.
5. Click **End capture**. Transfer the original files from each X5 into `insta/insta_right/` and, for dual arm, `insta/insta_left/` within the same session. Preserve the chapter files and their sidecars. The session also contains the capture manifest, event log, Tracker CSVs, and transfer manifest.

BLE commands control continuous recording to the X5s. Episode markers are saved on the host timeline, and the video is divided into episodes during offline processing. See [DataProcess](../dataprocess/README.md) for the compatible INSV workflow.

## Other camera modes

**Wired USB** records the native UVC stream to the workstation and displays a live preview. For the supported X3 profile, the stream is 1920×1080 MJPEG at 30 Hz with vertically stacked fisheyes. Build the worker on Ubuntu and assign a separate stable `video-index0` path to each physical camera.

```sh
sudo apt install g++ pkg-config libavcodec-dev libavutil-dev libswscale-dev
bash datacap/camera_usb/build_worker.sh
cp datacap/config.usb_webcam.example.json datacap/config.usb_webcam.json
ls -l /dev/v4l/by-path/*video-index0
python -m datacap.webapp --config datacap/config.usb_webcam.json
```

UVC sessions have a dedicated stage-01 reader. X3 Webcam supplies neither the INSV gyro nor the FlowState contract required by the documented X5 processing path.

**MVS Cameras** requires a separate Hikrobot MVS SDK and ExUMI installation. Configure `insta.mvs_exumi_root`, `insta.mvs_python`, and the hardware serials under `insta.mvs_serials`. The MVS-to-Zarr processing path is separate from this release's X5 workflow.

## Build the Ubuntu package

On Ubuntu 24.04, install `rsync` and the UVC build dependencies listed above, then run:

```sh
bash datacap/tools/package_deb_ubuntu.sh
sudo apt install ./datacap/dist/InstaDataCap_0.3.9_amd64.deb
systemctl --user daemon-reload
systemctl --user enable --now instadatacap.service
instadatacap-open
```

Substitute the built file name for another architecture. The package installs an **InstaDataCap** launcher, creates a per-user config at `~/.config/instadatacap/config.json`, and reads Tracker Wi-Fi settings from the same directory. Complete those files with your device settings. The launcher starts a user service and opens the loopback web UI. Restart the service after editing when a recording is no longer active.

See [third-party notices](THIRD_PARTY_NOTICES.md).
