import hid
import struct
import numpy as np
import time
import json
import logging
from builtins import print as _builtin_print
from pathlib import Path

from .enums_usb import *
from .enums_horusd_hid import *
from .enums_horusd_wifi import * # currently unused
from .enums_horusd_misc import * # currently unused
from .enums_horusd_status import *
from .enums_horusd_rf_report import *
from .enums_horusd_ack import *
from .enums_horusd_dongle import *


logger = logging.getLogger(__name__)
_VERBOSE_PRINTS = True


def firmware_quaternion_xyzw_to_api_wxyz(raw_quaternion):
    """Convert the four firmware float16 values from XYZW to API WXYZ.

    The reverse-engineered packet stores four float16 values in the same
    XYZW order used by OpenXR/Scipy.  :class:`TrackerPose` keeps its historical
    WXYZ public API, so the only valid component move is ``[x,y,z,w]`` to
    ``[w,x,y,z]``.  In particular, Y and Z must not be exchanged.
    """

    raw = np.asarray(raw_quaternion, dtype=np.float32)
    if raw.shape != (4,) or not np.all(np.isfinite(raw)):
        raise ValueError("firmware quaternion must contain four finite XYZW values")
    return np.array([raw[3], raw[0], raw[1], raw[2]], dtype=np.float32)


def capture_hid_read_host_clocks():
    """Capture host clocks immediately after a HID read returns.

    ``CLOCK_REALTIME`` is useful for joining a capture to other host logs,
    while the monotonic clocks are immune to wall-clock adjustments.  Not
    every Python/platform combination exposes ``CLOCK_MONOTONIC_RAW``; keep
    that value unavailable instead of substituting a different clock.
    """

    realtime_ns = time.time_ns()
    monotonic_ns = time.monotonic_ns()
    monotonic_raw_ns = None
    clock_monotonic_raw = getattr(time, "CLOCK_MONOTONIC_RAW", None)
    clock_gettime_ns = getattr(time, "clock_gettime_ns", None)
    if clock_monotonic_raw is not None and clock_gettime_ns is not None:
        try:
            monotonic_raw_ns = clock_gettime_ns(clock_monotonic_raw)
        except (OSError, ValueError):
            # The symbol can exist even when the running kernel does not
            # support it.  Do not silently replace it with CLOCK_MONOTONIC.
            pass
    return {
        "hid_read_host_realtime_ns": realtime_ns,
        "hid_read_host_monotonic_ns": monotonic_ns,
        "hid_read_host_monotonic_raw_ns": monotonic_raw_ns,
    }


def set_tracker_core_verbose(enabled: bool) -> None:
    """Globally enable/disable verbose logging for tracker_core."""

    global _VERBOSE_PRINTS
    _VERBOSE_PRINTS = enabled


def verbose_print(*args, **kwargs):
    if _VERBOSE_PRINTS:
        _builtin_print(*args, **kwargs)
        return

    sep = kwargs.get("sep", " ")
    end = kwargs.get("end", "\n")
    try:
        message = sep.join(str(arg) for arg in args) + end.rstrip("\n")
    except Exception:
        message = "<unprintable message>"
    logger.debug(message)


def _open_hid_path(path):
    """Open a HID path with either supported Python hidapi binding."""

    device_class = getattr(hid, "Device", None)
    if device_class is not None:
        return device_class(path=path)
    device = hid.device()
    device.open_path(path)
    return _LowercaseHidDeviceAdapter(device)


class _LowercaseHidDeviceAdapter:
    """Normalize the lowercase binding's list reports to bytes."""

    def __init__(self, device):
        self._device = device

    def __getattr__(self, name):
        return getattr(self._device, name)

    def read(self, *args, **kwargs):
        return bytes(self._device.read(*args, **kwargs))

    def get_feature_report(self, *args, **kwargs):
        return bytes(self._device.get_feature_report(*args, **kwargs))

# Sometimes it will not track w/o:
# adb shell setprop persist.lambda.trans_setup 1
# adb shell setprop persist.lambda.normalmode 0 
# adb shell setprop persist.lambda.3rdhost 1 
# tracking_mode 1 seems to fuck up trans_setup?

# client trackers sometimes need:
# adb shell rm -rf /data/lambda/ 
# adb shell mkdir -p /data/lambda/
# adb shell rm /data/mapdata/\*

# adb shell cat /data/tracking_log/horusd.log.0
# adb shell cat /data/tracking_log/slam.log.1
# adb shell cat /data/tracking_log/slam.log.\* > test_slam_client.log 
# adb shell cat /data/tracking_log/slam.log.\* > test_slam_host.log 

# Doesn't work :(
# cp /data/property/persist.lambda.3rdhost /data/property/persist.tracking.mode.largescale
# rm /data/property/persist.tracking.mode.largescale


def current_milli_time():
    return round(time.time() * 1000)


POSE_STREAM_REARM_DELAY_MS = 750
POSE_STREAM_REARM_INTERVAL_MS = 1000
# Dongle TX completion only confirms that the RF command was accepted locally;
# it does not confirm that the tracker consumed it.  Back-to-back mode/config
# commands can therefore leave an already-connected tracker in ATM-1 (button
# reports only) when the final ATM20 packet is lost.  Keep at least one RF frame
# between commands and send the final, idempotent pose-stream mode redundantly.
INDEPENDENT_SLAM_COMMAND_SPACING_SECONDS = 0.05
INDEPENDENT_SLAM_MODE_RETRY_COUNT = 3

def hex_dump(b, prefix=""):
    p = prefix
    b = bytes(b)
    for i in range(0, len(b)):
        if i != 0 and i % 16 == 0:
            verbose_print(p)
            p = prefix
        p += ("%02x " % b[i])
    verbose_print(p)

def mac_str(b):
    return hex(b[0])[2:] + ":" + hex(b[1])[2:] + ":" + hex(b[2])[2:] + ":" + hex(b[3])[2:] + ":" + hex(b[4])[2:] + ":" + hex(b[5])[2:] 

def mac_to_idx(b):
    if type(b) is int:
        return b
    return b[1] & 0xF

def do_u8_checksum(data):
    out = 0
    for i in range(0, len(data)):
        out ^= data[i]
    return out

# Base class which implements ACK commands
class Ackable(object):

    def _deliver_pose(self, device_addr, pose_data, packet_metadata=None):
        """Invoke the legacy raw callback while exposing packet metadata.

        Raw pyvut callbacks historically accept exactly three positional
        arguments.  Keeping that signature avoids breaking callers; the
        synchronous high-level parser reads ``_current_pose_packet_metadata``
        while the callback is running and copies it into the emitted sample.
        """

        if not self.pose_callback:
            return
        self._current_pose_packet_metadata = dict(packet_metadata or {})
        try:
            self.pose_callback(self, device_addr, pose_data)
        finally:
            self._current_pose_packet_metadata = None

    def lambda_end_map(self, device_addr):
        self.send_ack_to(mac_to_idx(device_addr), ACK_END_MAP)

    def send_ack_to(self, idx, ack):
        verbose_print("UNIMPLEMENTED")

    def send_ack_to_all(self, ack):
        for i in range(0, 5):
            self.send_ack_to(i, ack)

    def wifi_connect(self, idx):
        self.send_ack_to(idx, ACK_WIFI_CONNECT)

    #def wifi_set_ssid_password(self, idx, ssid, passwd):
    #    self.send_ack_to(idx, f"{ACK_WIFI_SSID_PASS}{ssid},{passwd}")

    def wifi_set_ssid(self, idx, ssid):
        verbose_print(ssid[:8])
        self._wifi_set_ssid_full(idx, ssid[:8])
        for i in range(8, len(ssid), 8):
            verbose_print(ssid[i:i+8])
            self._wifi_set_ssid_append(idx, ssid[i:i+8])

    def _wifi_set_ssid_full(self, idx, ssid):
        self.send_ack_to(idx, ACK_WIFI_SSID_FULL + ssid)

    def _wifi_set_ssid_append(self, idx, ssid):
        self.send_ack_to(idx, ACK_WIFI_SSID_APPEND + ssid)

    def wifi_set_country(self, idx, country):
        self.send_ack_to(idx, ACK_WIFI_COUNTRY + country)

    def wifi_set_password(self, idx, passwd):
        self.send_ack_to(idx, ACK_WIFI_PW + passwd)

    def wifi_set_freq(self, idx, freq):
        self.send_ack_to(idx, f"{ACK_WIFI_FREQ}{freq}")

    def ack_set_role_id(self, idx, rid):
        self.send_ack_to(idx, f"{ACK_ROLE_ID}{rid}")

    def ack_set_tracking_mode(self, idx, mode):
        self.send_ack_to(idx, f"{ACK_TRACKING_MODE}{mode}")

    def ack_set_tracking_host(self, idx, val):
        self.send_ack_to(idx, f"{ACK_TRACKING_HOST}{val}")

    def ack_set_wifi_host(self, idx, val):
        self.send_ack_to(idx, f"{ACK_WIFI_HOST}{val}")

    def ack_set_new_id(self, idx, val):
        self.send_ack_to(idx, f"{ACK_NEW_ID}{val}")

    def ack_lambda_ask_status(self, idx, key_id):
        self.send_ack_to(idx, f"{ACK_LAMBDA_ASK_STATUS}{key_id}")

    def ack_lambda_property(self, idx):
        self.send_ack_to(idx, ACK_LAMBDA_PROPERTY)

class DongleHID(Ackable):

    def __init__(
        self,
        wifi_info_path=None,
        independent_slam=False,
        enable_pairing_on_start=True,
        preserve_tracker_profile=False,
    ):
        self.independent_slam = bool(independent_slam)
        # Windows/VIVE Hub stores a map/profile relationship on the trackers.
        # In preservation mode the dongle transport may query identity/status,
        # but it must not change pairing, SLAM role, host/client state, device
        # ID, Wi-Fi settings, or map state.
        self.preserve_tracker_profile = bool(preserve_tracker_profile)
        if self.preserve_tracker_profile:
            enable_pairing_on_start = False
        self.calib_1 = ""
        self.calib_2 = ""
        self.device_macs = []
        self.got_a_pair = False
        self.num_paired = 0
        self.device_hid1 = None
        self.current_host_id = -1
        self.tick_periodic = 0

        self.pose_callback = None
        self.ack_callback = None
        self.connected_callback = None
        self.disconnected_callback = None

        self.pair_state = [0,0,0,0,0]
        self.device_info_by_slot = [{} for _ in range(5)]
        self.profile_identity_queried_slots = set()
        self.profile_pose_stream_requested_slots = set()
        self.blocked_profile_commands_seen = set()
        # A tracker may already be RF-connected before this process starts. In
        # that case the dongle reports a paired slot but does not necessarily
        # emit a fresh DRESP_PAIR_EVENT, so remember which slots this process
        # has configured for pose streaming.
        self.initialized_independent_slam_slots = set()
        self.connected_to_host = [False]*5
        self.has_host_map = [False]*5

        self.last_host_map_ask_ms = current_milli_time()

        self.host_ssid = ""
        self.host_passwd = ""
        self.host_freq = ""

        device_list = hid.enumerate(VID_VIVE, PID_DONGLE)
        verbose_print(device_list)

        # TODO better error handling
        device_dict_hid1 = [device for device in device_list if device['interface_number'] == HID1_INTERFACE_NUM][0]
        self.device_hid1 = _open_hid_path(device_dict_hid1['path'])

        verbose_print(self.get_PCBID()) # RequestPCBID
        verbose_print(self.get_SKUID()) # RequestSKUID
        verbose_print(self.get_SN()) # RequestSN
        verbose_print(self.get_ShipSN()) # RequestShipSN
        verbose_print(self.get_CapFPC()) # RequestCapFPC
        verbose_print(self.get_ROMVersion()) # QueryROMVersion


        # hex_dump(self.send_cmd(0x21, [0])) # bricked my dongle :(

        # 0x1D = ReportRequestRFChangeBehavior?
        if enable_pairing_on_start:
            bEnabled = 1
            verbose_print(self.send_cmd(DCMD_REQUEST_RF_CHANGE_BEHAVIOR, struct.pack("<BBBBBBB", RF_BEHAVIOR_PAIR_DEVICE, bEnabled, 1, 1, 1, 0, 0))) # PairDevice
        #verbose_print(self.send_cmd(DCMD_REQUEST_RF_CHANGE_BEHAVIOR, struct.pack("<BBBBBBB", RF_BEHAVIOR_RX_POWER_SAVING, bEnabled, 1, 0, 0, 0, 0))) # RxPowerSaving?
        #verbose_print(self.send_cmd(DCMD_REQUEST_RF_CHANGE_BEHAVIOR, struct.pack("<BBBBBB", RF_BEHAVIOR_RESTART_RF, 1, 0, 0, 0, 0))) # Same as 1 w/ bEnabled
        # 3 = SetLpf (7,8,9,10), not available
        # what is 4?
        #verbose_print(self.send_cmd(DCMD_REQUEST_RF_CHANGE_BEHAVIOR, struct.pack("<B", RF_BEHAVIOR_FACTORY_RESET))) # FactoryReset?
        #verbose_print(self.send_cmd(DCMD_REQUEST_RF_CHANGE_BEHAVIOR, struct.pack("<BBBBBB", RF_BEHAVIOR_6, 1, 0, 0, 0, 0))) # ClearPairingInfo?

        wifi_path = Path(wifi_info_path) if wifi_info_path else Path(__file__).with_name('wifi_info.json')
        with wifi_path.open('r', encoding='utf-8') as f:
            self.wifi_info = json.load(f)

    def close(self):
        """Release the HID handle so a re-enumerated dongle can be reopened."""

        device = self.device_hid1
        self.device_hid1 = None
        if device is not None:
            device.close()

    def parse_response(self, data):
        err_ret, cmd_id, data_len, unk2 = struct.unpack("<BBBH", data[:5])
        #verbose_print(f"unk: {hex(unk)} cmd_id: {hex(cmd_id)} data_len: {hex(data_len)} unk2: {hex(unk2)} ")

        ret = data[5:5+data_len-4]
        return err_ret, cmd_id, ret

    def parse_incoming(self, data):
        cmd_id, data_len, unk = struct.unpack("<BBH", data[:4])
        #verbose_print(f"unk: {hex(unk)} cmd_id: {hex(cmd_id)} data_len: {hex(data_len)} unk2: {hex(unk2)} ")

        ret = data[4:4+data_len-4]
        return cmd_id, ret

    def parse_tracker_status(self, data):
        unk, data_len = struct.unpack("<BB", data[:2])
        #verbose_print(f"unk: {hex(unk)} data_len: {hex(data_len)}")
        hex_dump(data[:2])
        data = data[2:2+data_len]
        hex_dump(data[0:1])
        data = data[1:]
        pair_state = [0,0,0,0,0]
        unk, pair_state[0],pair_state[1],pair_state[2],pair_state[3],pair_state[4],  = struct.unpack("<HLLLLL", data)
        verbose_print(hex(unk),hex(pair_state[0]),hex(pair_state[1]),hex(pair_state[2]),hex(pair_state[3]),hex(pair_state[4]))

        self.pair_state = pair_state

        # Recover trackers that were connected before the application opened.
        # Previously their status light could show connected while no pose
        # packets were produced because initialization only ran on a new pair
        # event.
        if self.preserve_tracker_profile:
            for idx, state in enumerate(self.pair_state):
                if state & PAIR_STATE_PAIRED:
                    if idx not in self.profile_identity_queried_slots:
                        self.send_ack_to(idx, ACK_REQUEST_DEVICE_INFO)
                        self.profile_identity_queried_slots.add(idx)
                    self.request_preserved_pose_stream(idx)
        elif self.independent_slam:
            for idx, state in enumerate(self.pair_state):
                if state & PAIR_STATE_PAIRED:
                    self.initialize_independent_slam_slot(idx)

        # Fallback for disconnects
        if self.current_host_id >= 0:
            if self.pair_state[self.current_host_id] & PAIR_STATE_PAIRED == 0:
                self.handle_disconnected(self.current_host_id)

        # pair state:
        # 0x4000003 - unpaired, pairing info present?
        # 0x1000003 - unpaired, pairing info not present?
        # 0x320fc008 - paired
        # 0x320ff808 - paired
        # 0x320fa808 - paired


    def send_raw(self, data=None, pad=True):
        if data is None:
            data = []
        out = bytes(data)

        if pad:
            out += bytes([0x0] * (0x40 - len(out)))
        #verbose_print("Sending raw:")
        #hex_dump(out)

        try:
            ret = self.device_hid1.send_feature_report(out)

            resp = self.device_hid1.get_feature_report(0, 0x40)
            #hex_dump(resp)
                
            return resp
        except:
            return bytes([])

        return bytes([])

    def send_cmd(self, cmd_id, data=None):
        if data is None:
            data = []
        if type(data) is str:
            data = data.encode("utf-8")
        out = struct.pack("<BBB", 0, cmd_id, len(data)+2)
        out += bytes(data)

        out += bytes([0x0] * (0x41 - len(out)))

        #verbose_print(f"Sending idk:")
        #hex_dump(out)

        try:
            ret = self.device_hid1.send_feature_report(out)
            for i in range(0, 10):
                resp = self.device_hid1.get_feature_report(0, 0x40)
                #hex_dump(resp)
                err_ret, cmd_ret, data_ret = self.parse_response(resp)
                #hex_dump(data_ret)
                if err_ret:
                    verbose_print(f"Got error response: {hex(err_ret)}")
                if cmd_ret == cmd_id:
                    return data_ret
        except:
            return bytes([])

        return bytes([])

    def send_F4(self, trackers, subcmd, data=None):
        if data is None:
            data = []
        if len(trackers) != 5:
            return bytes([])
        checksummed_data = bytes(trackers) + bytes([subcmd]) + bytes(data)
        out_data = bytes([do_u8_checksum(checksummed_data)]) + checksummed_data
        hex_dump(out_data)
        return self.send_cmd(DCMD_F4, out_data)

    def is_host(self, device_addr):
        if self.independent_slam:
            return True
        return mac_to_idx(device_addr) == self.current_host_id

    def is_client(self, device_addr):
        return not self.is_host(device_addr)

    def client_has_host_map(self, device_addr):
        return self.has_host_map[mac_to_idx(device_addr)]

    def is_client_connected(self, device_addr):
        if self.is_host(device_addr): return True
        return self.connected_to_host[mac_to_idx(device_addr)]

    def set_pose_callback(self, callback_fn, callback_ref):
        self.pose_callback = callback_fn
        self.pose_callback_ref = callback_ref

    def parse_tracker_incoming(self, resp, hid_read_host_clocks=None):
        cmd_id, pkt_idx, device_addr, type_maybe, data_len = struct.unpack("<BH6sHB", resp[:0xC])
        #hex_dump(resp)
        #verbose_print(hex(cmd_id), hex(pkt_idx), mac_str(device_addr), hex(type_maybe), "data_len:", hex(data_len))

        if type_maybe == 0x101:
            data_raw = resp[0xC:0xC+data_len]
            if self.ack_callback:
                self.ack_callback(self, device_addr, data_raw)
            return
        elif type_maybe == 0x110:
            data = resp[0xC:0xC+data_len]
            #self.parse_pose_data(device_addr, data)
            packet_metadata = dict(hid_read_host_clocks or {})
            packet_metadata.update(
                {
                    # Reverse-engineered RF report field.  It is retained as
                    # an integer counter; wrap behavior has not been proven.
                    "source_packet_index_raw": int(pkt_idx),
                    "source_hmd_us_raw": None,
                    "source_pose_index_raw": None,
                    "source_pose_timestamp_raw": None,
                    "source_netsync_raw": (),
                }
            )
            self._deliver_pose(device_addr, data, packet_metadata)
            return

        data = resp[0xC:0xC+data_len]
        data_id = data[0]
        data_real = data[1:]
        verbose_print("   data_id:", hex(data_id), "data:", data_real)

    def get_PCBID(self):
        return self.send_cmd(DCMD_GET_CR_ID, [CR_ID_PCBID]).decode("utf-8")

    def get_SKUID(self):
        return self.send_cmd(DCMD_GET_CR_ID, [CR_ID_SKUID]).decode("utf-8")

    def get_SN(self):
        return self.send_cmd(DCMD_GET_CR_ID, [CR_ID_SN]).decode("utf-8")

    def get_ShipSN(self):
        return self.send_cmd(DCMD_GET_CR_ID, [CR_ID_SHIP_SN]).decode("utf-8")

    def get_CapFPC(self):
        return self.send_cmd(DCMD_GET_CR_ID, [CR_ID_CAP_FPC]).decode("utf-8")

    def get_ROMVersion(self):
        return self.send_cmd(DCMD_QUERY_ROM_VERSION, [0x00]).decode("utf-8")

    def send_ack_to(self, idx, ack):
        if idx < 0:
            return
        if (
            getattr(self, "preserve_tracker_profile", False)
            and not self._is_profile_preserving_ack(ack)
        ):
            key = (int(idx), str(ack))
            seen = getattr(self, "blocked_profile_commands_seen", None)
            if not isinstance(seen, set):
                seen = set()
                self.blocked_profile_commands_seen = seen
            if key not in seen:
                logger.warning(
                    "Blocked tracker command in profile-preservation mode: "
                    "slot=%s ack=%r",
                    idx,
                    ack,
                )
                seen.add(key)
            return None

        mac = [0x23, 0x30, 0x42, 0xB7, 0x82, 0xD3]
        mac[1] |= idx

        # TX_ACK_TO_MAC checks all MAC bytes,
        # TX_ACK_TO_PARTIAL_MAC checks the first 2
        preamble = struct.pack("<BBBBBBBBB", TX_ACK_TO_PARTIAL_MAC, mac[0],mac[1],mac[2],mac[3],mac[4],mac[5],0, 1)
        ack = struct.pack("<B", len(ack)) + ack.encode("utf-8")

        data = preamble + ack

        return self.send_cmd(DCMD_TX, data)

    @staticmethod
    def _is_profile_preserving_ack(ack):
        """Allow read-only queries plus the exact 6DoF stream-start command."""

        ack = str(ack)
        return (
            ack == ACK_REQUEST_DEVICE_INFO
            or ack == ACK_LAMBDA_PROPERTY
            or ack.startswith(ACK_LAMBDA_ASK_STATUS)
            or ack
            == f"{ACK_TRACKING_MODE}{TRACKING_MODE_SLAM_HOST}"
        )

    def request_preserved_pose_stream(self, idx):
        """Start pose reports without changing pairing, identity, role, or map.

        VIVE stops sending full pose packets after some RF/API restarts. ATM20 is
        the operational stream-start command already used by the working path;
        unlike ATM-1, ARI, ATH, AWH, ANI, and P64:3, it does not reset or
        reassign the Windows/VIVE Hub profile.
        """

        idx = int(idx)
        if not getattr(self, "preserve_tracker_profile", False):
            return False
        if idx < 0 or idx >= len(self.pair_state):
            return False
        if not int(self.pair_state[idx]) & PAIR_STATE_PAIRED:
            return False
        requested = getattr(self, "profile_pose_stream_requested_slots", None)
        if not isinstance(requested, set):
            requested = set()
            self.profile_pose_stream_requested_slots = requested
        if idx in requested:
            return False
        return self.refresh_preserved_pose_stream(idx)

    def paired_tracker_slots(self):
        """Return the dongle slots currently reported as paired."""

        return tuple(
            idx
            for idx, state in enumerate(self.pair_state)
            if int(state) & PAIR_STATE_PAIRED
        )

    def refresh_preserved_pose_stream(self, idx):
        """Re-request pose reports without changing the preserved profile.

        Only the already-whitelisted ATM20 pose-stream command is sent.  This
        method never enters pairing or writes role, host/client, device-ID,
        Wi-Fi, or map state.
        """

        idx = int(idx)
        if not getattr(self, "preserve_tracker_profile", False):
            return False
        if idx < 0 or idx >= len(self.pair_state):
            return False
        if not int(self.pair_state[idx]) & PAIR_STATE_PAIRED:
            return False
        for _ in range(INDEPENDENT_SLAM_MODE_RETRY_COUNT):
            self._send_independent_slam_ack(
                idx,
                f"{ACK_TRACKING_MODE}{TRACKING_MODE_SLAM_HOST}",
            )
        requested = getattr(self, "profile_pose_stream_requested_slots", None)
        if not isinstance(requested, set):
            requested = set()
            self.profile_pose_stream_requested_slots = requested
        requested.add(idx)
        return True

    def handle_disconnected(self, idx):
        if idx < 0:
            return
        if idx == self.current_host_id:
            self.current_host_id = -1

        self.connected_to_host[idx] = False
        self.has_host_map[idx] = False
        self.initialized_independent_slam_slots.discard(idx)
        self.profile_identity_queried_slots.discard(idx)
        self.profile_pose_stream_requested_slots.discard(idx)

        if self.disconnected_callback:
            self.disconnected_callback(self, idx)

    def initialize_independent_slam_slot(self, idx):
        """Configure one paired dongle slot as an independent SLAM host."""

        idx = int(idx)
        if getattr(self, "preserve_tracker_profile", False):
            return False
        if idx < 0 or idx >= len(self.pair_state):
            return False
        if idx in self.initialized_independent_slam_slots:
            return False

        verbose_print(f"Initializing dongle slot {idx} as an independent SLAM tracker")
        self._send_independent_slam_ack(idx, f"{ACK_ROLE_ID}1")
        self._send_independent_slam_ack(idx, f"{ACK_TRACKING_MODE}-1")
        self._send_independent_slam_ack(
            idx,
            f"{ACK_WIFI_COUNTRY}{self.wifi_info['country']}",
        )
        self._send_independent_slam_ack(idx, f"{ACK_TRACKING_HOST}1")
        self._send_independent_slam_ack(idx, f"{ACK_WIFI_HOST}1")
        # Preserve the unique dongle slot. Assigning every tracker ID 0 makes
        # their RF identities collide and one stream disappears.
        self._send_independent_slam_ack(idx, f"{ACK_NEW_ID}{idx}")
        for _ in range(INDEPENDENT_SLAM_MODE_RETRY_COUNT):
            self._send_independent_slam_ack(
                idx,
                f"{ACK_TRACKING_MODE}{TRACKING_MODE_SLAM_HOST}",
            )
        self._send_independent_slam_ack(idx, ACK_REQUEST_DEVICE_INFO)
        self.initialized_independent_slam_slots.add(idx)
        if self.current_host_id == -1:
            self.current_host_id = idx
        return True

    def _send_independent_slam_ack(self, idx, ack):
        """Send one preserved-pairing tracker command with RF delivery spacing."""

        self.send_ack_to(idx, ack)
        time.sleep(INDEPENDENT_SLAM_COMMAND_SPACING_SECONDS)

    def rearm_independent_slam_slot(self, idx):
        """Restore only the 6DoF pose stream for an RF-connected tracker.

        This deliberately does not resend ATM-1, ANI, role, Wi-Fi country, host
        assignment, PairDevice, or any map command.  Repeating the complete
        startup sequence used to make recovery self-defeating: a dropped final
        ATM20 command left the tracker in the preceding ATM-1 button-only mode.
        """

        idx = int(idx)
        if getattr(self, "preserve_tracker_profile", False):
            return False
        if idx < 0 or idx >= len(self.pair_state):
            return False
        verbose_print(
            f"Re-arming only the independent SLAM pose stream for dongle slot {idx}"
        )
        for _ in range(INDEPENDENT_SLAM_MODE_RETRY_COUNT):
            self._send_independent_slam_ack(
                idx,
                f"{ACK_TRACKING_MODE}{TRACKING_MODE_SLAM_HOST}",
            )
        return True

    def do_loop(self):
        resp = self.device_hid1.read(0x400)
        hid_read_host_clocks = capture_hid_read_host_clocks()
        if len(resp) <= 0:
            return
        #verbose_print("dump:")
        #hex_dump(resp)
        #verbose_print("parsed:")
        # 0x18 = paired event, gives the 
        if resp[0] == DRESP_PAIR_EVENT:
            self.got_a_pair = True
            #verbose_print("dump:")
            #hex_dump(resp)
            cmd_ret, data_ret = self.parse_incoming(resp)
            #hex_dump(data_ret)
            unk = data_ret[0]
            is_unpair = data_ret[1] # 0x1, id?
            paired_mac = data_ret[2:]
            paired_mac_str = mac_str(paired_mac)
            if paired_mac not in self.device_macs:
                self.device_macs += [paired_mac]
                self.num_paired += 1
            verbose_print(("Unpaired" if is_unpair else "Paired") + f" {paired_mac_str}, {hex(unk)}")
            #verbose_print(self.device_macs)
            self.calib_1 = ""
            self.calib_2 = ""

            if is_unpair:
                self.handle_disconnected(mac_to_idx(paired_mac))
                return

            if self.preserve_tracker_profile:
                # Keep the Windows/VIVE Hub map and device-role association
                # intact. Identity discovery is read-only and is needed for
                # stable htc_left/htc_right routing.
                self.send_ack_to(mac_to_idx(paired_mac), ACK_REQUEST_DEVICE_INFO)
                self.profile_identity_queried_slots.add(mac_to_idx(paired_mac))
                self.request_preserved_pose_stream(mac_to_idx(paired_mac))
                return

            # I really wish they included the index of each tracker *somewhere*, but it seems
            # like the MACs have always been fake anyhow
            # TODO: detect re-pairs and force re-init
            
            # A VIVE Ultimate Tracker has its own cameras and can run its own
            # inside-out SLAM. The old host/client branch forced every tracker
            # after the first into TRACKING_MODE_SLAM_CLIENT (gyro-only), which
            # made dual-arm capture incapable of getting two 6DoF poses at once.
            if self.independent_slam:
                verbose_print(f"Making {paired_mac_str} an independent SLAM tracker")
                self.initialize_independent_slam_slot(mac_to_idx(paired_mac))
                return
            elif self.current_host_id == -1 or self.is_host(paired_mac):
                self.ack_set_role_id(mac_to_idx(paired_mac), 1)
                self.ack_set_tracking_mode(mac_to_idx(paired_mac), -1)
                test_mode = TRACKING_MODE_SLAM_HOST
                self.current_host_id = mac_to_idx(paired_mac)
                verbose_print(f"Making {paired_mac_str} the SLAM host")
                self.wifi_set_country(mac_to_idx(paired_mac), self.wifi_info["country"])
                self.ack_set_tracking_host(mac_to_idx(paired_mac), 1)
                self.ack_set_wifi_host(mac_to_idx(paired_mac), 1)
                self.ack_set_new_id(mac_to_idx(paired_mac), 0)
            else:
                self.ack_set_role_id(mac_to_idx(paired_mac), 1)
                self.ack_set_tracking_mode(mac_to_idx(paired_mac), -1)
                test_mode = TRACKING_MODE_SLAM_CLIENT
                #self.wifi_connect(mac_to_idx(paired_mac))
                new_id = int(mac_to_idx(paired_mac))

                self.ack_set_tracking_host(mac_to_idx(paired_mac), 0)
                self.ack_set_wifi_host(mac_to_idx(paired_mac), 0)
                self.ack_set_new_id(mac_to_idx(paired_mac), new_id)

            self.ack_set_tracking_mode(mac_to_idx(paired_mac), test_mode)

            
        elif resp[0] == DRESP_TRACKER_RF_STATUS or resp[0] == DRESP_TRACKER_NEW_RF_STATUS or resp[0] == 0x29:
            verbose_print(f"dump for {hex(resp[0])}:")
            #hex_dump(resp)
            cmd_ret, data_ret = self.parse_incoming(resp)
            if resp[0] == DRESP_TRACKER_RF_STATUS or resp[0] == DRESP_TRACKER_NEW_RF_STATUS:
                self.parse_tracker_status(data_ret)
            else:
                hex_dump(data_ret)
        elif resp[0] == DRESP_TRACKER_INCOMING:
            self.parse_tracker_incoming(resp, hid_read_host_clocks)
            #self.send_raw(bytes([0]) + resp)

            # These commands feel sketchy...
            #hex_dump(self.send_F4([1,1,1,1,1], 0))
            #hex_dump(self.send_F4([1,1,1,1,1], 1, struct.pack("<BL", 0, 0)))
            
            #self.send_ack_to_all(ACK_TRACKING_MODE + "1")
            #self.send_ack_to_all("ATW")
            
            #self.send_ack_to_all(ACK_LAMBDA_SET_STATUS + f"{KEY_TRANSMISSION_READY},1")
            #self.send_ack_to_all(ACK_LAMBDA_ASK_STATUS + f"{KEY_CURRENT_MAP_ID}")
            
            self.tick_periodic += 1
            if self.tick_periodic > 1000:
                verbose_print("Tick!")
                #self.send_ack_to_all(ACK_LAMBDA_MESSAGE + "1:0")
                

                #self.send_ack_to_all(ACK_LAMBDA_SET_STATUS + f"{KEY_TRANSMISSION_READY},1")
                #self.send_ack_to_all(ACK_ATW)


                for i in range(0, 5):
                    if not self.is_client_connected(i): continue
                    self.ack_lambda_ask_status(i, KEY_TRANSMISSION_READY)
                    self.ack_lambda_ask_status(i, KEY_CURRENT_MAP_ID)
                    self.ack_lambda_ask_status(i, KEY_MAP_STATE)
                    self.ack_lambda_ask_status(i, KEY_CURRENT_TRACKING_STATE)

                    #self.send_ack_to(i, ACK_NEW_ID + f"{i}")
                    #self.wifi_connect(i)
                    #self.wifi_set_ssid(i, self.wifi_info["ssid"])
                    #self.wifi_set_password(i, self.wifi_info["pass"])
                    #self.wifi_set_country(i, self.wifi_info["country"])
                    
                    if i != self.current_host_id:
                        self.ack_lambda_ask_status(i, KEY_RECEIVED_HOST_ED)
                        self.ack_lambda_ask_status(i, KEY_RECEIVED_HOST_MAP)
                    
                    #    self.send_ack_to(i, ACK_LAMBDA_COMMAND + f"{ASK_ED}")
                    pass

                self.tick_periodic = 0
            #self.send_ack_to_all(ACK_LAMBDA_MESSAGE)
        else:
            verbose_print("dump:")
            hex_dump(resp)

class TrackerHID(Ackable):

    def __init__(self, wifi_info_path=None):
        self.watchdog_delay = 0
        self.poses_recvd = 0
        self.pose_callback = None
        self.ack_callback = None
        self.connected_callback = None
        self.disconnected_callback = None

        self.device_addr = bytes([0]*6)

        device_list = hid.enumerate(VID_VIVE, PID_TRACKER)
        verbose_print(device_list)

        #Find the device with the particular usage you want
        device_dict_hid1 = [device for device in device_list if device['interface_number'] == HID1_INTERFACE_NUM][0]
        self.device_hid1 = _open_hid_path(device_dict_hid1['path'])

        '''
        device_dict_hid3 = [device for device in device_list if device['interface_number'] == HID3_INTERFACE_NUM][0]
        device_hid3 = _open_hid_path(device_dict_hid3['path'])
        '''

        #self.set_tracking_mode(TRACKING_MODE_SLAM_HOST)
        #self.set_tracking_mode(0xFFFFFFFF)
        #self.set_tracking_mode(TRACKING_MODE_SLAM_HOST)
        self.set_power_pcvr(TRACKING_MODE_SLAM_HOST)

        wifi_path = Path(wifi_info_path) if wifi_info_path else Path(__file__).with_name('wifi_info.json')
        with wifi_path.open('r', encoding='utf-8') as f:
            self.wifi_info = json.load(f)

        '''
        self.send_ack_to(self.device_addr, ACK_FW + "1")
        self.wifi_set_ssid(self.device_addr, self.wifi_info["ssid"])
        self.wifi_set_password(self.device_addr, self.wifi_info["pass"])
        self.wifi_set_country(self.device_addr, self.wifi_info["country"])
        self.wifi_set_freq(self.device_addr, self.wifi_info["freq"])
        self.wifi_connect(self.device_addr)
        '''

    def close(self):
        """Release the directly connected tracker's HID handle."""

        device = self.device_hid1
        self.device_hid1 = None
        if device is not None:
            device.close()

    def parse_response(self, data):
        unk, cmd_id, data_len, unk2 = struct.unpack("<BHBB", data[:5])
        #verbose_print(f"unk: {hex(unk)} cmd_id: {hex(cmd_id)} data_len: {hex(data_len)} unk2: {hex(unk2)} ")

        ret = data[5:5+data_len]
        return cmd_id, ret

    def send_command(self, cmd_id, data=None):
        if data is None:
            data = []
        out = struct.pack("<HBB", cmd_id, len(data), 0)
        out += bytes(data)

        out += bytes([0x0] * (0x40 - len(out)))

        try:
            ret = self.device_hid1.send_feature_report(out)
            for i in range(0, 10):
                resp = self.device_hid1.get_feature_report(0, 0x40)
                #hex_dump(resp)
                cmd_ret, data_ret = self.parse_response(resp)
                #hex_dump(data_ret)
                if cmd_ret == cmd_id:
                    return data_ret
        except:
            return bytes([])

        return bytes([])

    # ACK related
    def send_ack_to(self, idx, ack):
        return self.send_ack(ack)

    def send_ack_to_all(self, ack):
        return self.send_ack(ack)

    def send_ack(self, ack):
        return self.send_command(PACKET_SET_ACK, ack.encode("utf-8"))

    def get_ack(self):
        return self.send_command(PACKET_GET_ACK)

    # Serial/device ino related
    def get_str_info(self, idx):
        return self.send_command(PACKET_GET_STR_INFO, [idx]).decode("utf-8")

    def set_str_info(self, idx, val):
        return self.send_command(PACKET_SET_STR_INFO, struct.pack("<BS", idx, val))

    def get_status(self):
        ret = self.send_command(PACKET_GET_STATUS)
        tracking_mode, power, batt, hmd_init, device_status_mask, btn = struct.unpack("<BBBBBL", ret)
        verbose_print(f"tracking_mode={tracking_mode}, power={power}, batt={batt}, hmd_init={hmd_init}, device_status_mask={hex(device_status_mask)}, btn={hex(btn)}")

    def set_tracking_mode(self, mode):
        self.send_command(PACKET_SET_TRACKING_MODE, [mode & 0xFF])

    def send_haptic(self, nDuration, nFrequency, nAmplitude, identify):
        self.send_command(PACKET_SET_HAPTIC, struct.pack("<HHHH", nDuration, nFrequency, nAmplitude, identify))

    # ex: bootloader, fastboot, etc. I think.
    def set_reboot(self, reason=""):
        self.send_command(PACKET_SET_REBOOT, reason.encode("utf-8"))

    def get_property(self, key):
        self.send_command(PACKET_GET_PROPERTY, key.encode("utf-8"))

    def parse_incoming(self):
        resp = self.device_hid1.read(0x400)
        hid_read_host_clocks = capture_hid_read_host_clocks()
        if len(resp) <= 0:
            return
        unk0, pkt_idx, mask, hmd_us, hdcc_status0, hdcc_status1, ack_in_queue, device_status, unk3 = struct.unpack("<BHLQBBBL17s", resp[:0x27])
        #hex_dump(resp)
        verbose_print(unk0, pkt_idx, hex(mask), hmd_us, hex(hdcc_status0), hex(hdcc_status1), ack_in_queue, hex(device_status), unk3)

        pose_records = []
        for i in range(0, 7):
            pose_len = resp[0x27 + (0x61*i)]
            pose_data = resp[0x28 + (0x61*i) : 0x28 + (0x61*i) + pose_len]
            pose_timestamp, = struct.unpack("<Q", resp[0x27 + (0x61*i) + 0x59 : 0x27 + (0x61*i) + 0x59 + 0x8])
            if pose_len:
                verbose_print("Pose data", i, "len", hex(pose_len), "ts", pose_timestamp)
                #hex_dump(pose_data)
                pose_records.append((i, pose_data, pose_timestamp))
        netsync_str = "netsync: "
        netsync_raw = []
        for i in range(0, 7):
            a,b = struct.unpack("<QQ", resp[0x2ce+(i*0x10):0x2ce+(i*0x10)+0x10])
            netsync_raw.append((int(a), int(b)))
            netsync_str += f"({a},{b}) "
        verbose_print(netsync_str)
        verbose_print("")
        verbose_print("")

        # Parse netsync before emitting any callbacks so each pose carries the
        # complete, unmodified packet values.  hmd_us/pose_timestamp/netsync
        # are reverse-engineered fields whose units and clock domains are not
        # yet verified, hence the explicit *_raw names.
        for pose_index, pose_data, pose_timestamp in pose_records:
            packet_metadata = dict(hid_read_host_clocks)
            packet_metadata.update(
                {
                    "source_packet_index_raw": int(pkt_idx),
                    "source_hmd_us_raw": int(hmd_us),
                    "source_pose_index_raw": int(pose_index),
                    "source_pose_timestamp_raw": int(pose_timestamp),
                    "source_netsync_raw": tuple(netsync_raw),
                }
            )
            self._deliver_pose(self.device_addr, pose_data, packet_metadata)

    # 1=gyro, 2=body tracking(?), 3=body?
    def set_power_pcvr(self, mode):
        self.send_command(PACKET_SET_POWER_PCVR, [mode & 0xFF])

    def kick_watchdog(self):
        self.watchdog_delay += 1
        if self.watchdog_delay < 1000:
            return
        self.send_command(PACKET_SET_WATCHDOG_KICK)
        self.watchdog_delay = 0

    # default 3?
    def set_camera_policy(self, val):
        self.send_command(PACKET_SET_CAMERA_POLICY, [val])

    # default 3?
    def set_camera_fps(self, val):
        self.send_command(PACKET_SET_CAMERA_FPS, [val])

    def do_loop(self):
        self.parse_incoming()
        self.kick_watchdog()

        #self.ack_lambda_property(self.device_addr)
        #self.lambda_end_map(self.device_addr)
        
        data = self.get_ack()
        # TODO: first byte is always 0xFF, why
        if data and len(data) > 1 and self.ack_callback:
            self.ack_callback(self, self.device_addr, data[1:])

    def is_host(self, device_addr):
        return True # TODO

    def is_client(self, device_addr):
        return not self.is_host(device_addr)

class ViveTrackerGroup():

    def __init__(
        self,
        mode="DONGLE_USB",
        wifi_info_path=None,
        debug=True,
        independent_slam=False,
        enable_pairing_on_start=True,
        preserve_tracker_profile=False,
    ):
        set_tracker_core_verbose(debug)
        self.poses_recvd = [0]*5
        self.full_poses_recvd = [0]*5
        self.pose_stream_button_only_since_ms = [0]*5
        self.pose_stream_last_rearm_ms = [0]*5
        self.pose_stream_rearm_count = [0]*5
        self.pose_quat = [[0.0, 0.0, 0.0, 1.0]] * 5
        self.pose_pos = [[0.0, 0.0, 0.0]] * 5
        self.pose_time = [0] * 5
        self.pose_tracking_status = [0] * 5
        self.pose_btns = [0]*5
        self.last_pose_btns = [0]*5
        #self.wip_pose_btns = [0]*5

        self.tracker_map_state = [0]*5
        self.stuck_on_static = [0]*5
        self.stuck_on_exists = [0]*5
        self.stuck_on_not_checked = [0]*5
        self.bump_map_once = [True]*5
        self.bump_map_once_2 = [True]*5

        self.pose_listeners = []
        self._active_tracker_slots = []

        # TODO: mix of multiple?
        if mode == "DONGLE_USB":
            self.comms = DongleHID(
                wifi_info_path=wifi_info_path,
                independent_slam=independent_slam,
                enable_pairing_on_start=enable_pairing_on_start,
                preserve_tracker_profile=preserve_tracker_profile,
            )
        elif mode == "TRACKER_USB":
            self.comms = TrackerHID(wifi_info_path=wifi_info_path)

        self.comms.pose_callback = self.parse_pose_data
        self.comms.ack_callback = self.parse_ack
        self.comms.connected_callback = self.handle_connected
        self.comms.disconnected_callback = self.handle_disconnected

    def close(self):
        """Break callback cycles and close the underlying HID transport."""

        comms = getattr(self, "comms", None)
        if comms is None:
            return
        self.comms = None
        comms.pose_callback = None
        comms.ack_callback = None
        comms.connected_callback = None
        comms.disconnected_callback = None
        comms.close()

    def add_pose_listener(self, listener):
        if listener not in self.pose_listeners:
            self.pose_listeners.append(listener)

    def remove_pose_listener(self, listener):
        self.pose_listeners = [cb for cb in self.pose_listeners if cb != listener]

    def clear_pose_listeners(self):
        self.pose_listeners.clear()

    def paired_tracker_slots(self):
        """Return paired RF slots without changing any tracker state."""

        getter = getattr(self.comms, "paired_tracker_slots", None)
        return tuple(getter()) if callable(getter) else ()

    def refresh_preserved_pose_stream(self, tracker_slot):
        """Use the profile-preserving transport refresh for one RF slot."""

        refresh = getattr(self.comms, "refresh_preserved_pose_stream", None)
        return bool(refresh(int(tracker_slot))) if callable(refresh) else False

    def handle_connected(self, comms, idx):
        pass

    def handle_disconnected(self, comms, idx):
        if idx < 0:
            return

        self.tracker_map_state[idx] = 0
        self.stuck_on_static[idx] = 0
        self.stuck_on_exists[idx] = 0
        self.stuck_on_not_checked[idx] = 0
        self.bump_map_once[idx] = True
        self.bump_map_once_2[idx] = True
        if idx in self._active_tracker_slots:
            self._active_tracker_slots.remove(idx)

    # TODO: comms -> self
    def handle_map_state(self, comms, device_addr, state):
        self.tracker_map_state[mac_to_idx(device_addr)] = state

        if self.stuck_on_static[mac_to_idx(device_addr)] > 7:
            verbose_print("ok we're stuck, end the map again")
            self.bump_map_once_2[mac_to_idx(device_addr)] = True
            self.stuck_on_static[mac_to_idx(device_addr)] = 0

        if self.stuck_on_exists[mac_to_idx(device_addr)] > 3:
            self.stuck_on_exists[mac_to_idx(device_addr)] = 0

        if self.stuck_on_not_checked[mac_to_idx(device_addr)] > 3:
            self.stuck_on_not_checked[mac_to_idx(device_addr)] = 0

        if state == MAP_REBUILD_WAIT_FOR_STATIC:
            #comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_COMMAND + f"{RESET_MAP}")
            self.stuck_on_static[mac_to_idx(device_addr)] += 1
            if self.bump_map_once_2[mac_to_idx(device_addr)]:
                if comms.is_client(device_addr):
                    verbose_print("End the map?")
                    #comms.lambda_end_map(comms.current_host_id)
                    #comms.lambda_end_map(device_addr)
                    #comms.send_ack_to(comms.current_host_id, ACK_LAMBDA_COMMAND + f"{ASK_MAP}")
                    #comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_COMMAND + f"{RESET_MAP}")
                self.bump_map_once_2[mac_to_idx(device_addr)] = False
            #comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_SET_STATUS + f"{KEY_MAP_STATE},{MAP_REBUILT}")
            #comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_SET_STATUS + f"{KEY_CURRENT_TRACKING_STATE},{MAP_REBUILD_CREATE_MAP}")
        else:
            self.bump_map_once_2[mac_to_idx(device_addr)] = True
            self.stuck_on_static[mac_to_idx(device_addr)] = 0

        if state == MAP_EXIST:
            if self.stuck_on_exists[mac_to_idx(device_addr)] == 0:# and comms.is_host(device_addr):
                verbose_print("ok we're stuck on exists, end the map again")
                #comms.lambda_end_map(device_addr)
            self.stuck_on_exists[mac_to_idx(device_addr)] += 1
        else:
            self.stuck_on_exists[mac_to_idx(device_addr)] = 0

        if state == MAP_NOT_CHECKED:
            if (
                not getattr(comms, "preserve_tracker_profile", False)
                and self.stuck_on_not_checked[mac_to_idx(device_addr)] == 0
                and comms.is_client(device_addr)
                and comms.client_has_host_map(device_addr)
            ):
                verbose_print("ok we're stuck on not checked, end the map again")
                comms.lambda_end_map(device_addr)
            self.stuck_on_not_checked[mac_to_idx(device_addr)] += 1
        else:
            self.stuck_on_not_checked[mac_to_idx(device_addr)] = 0

    def parse_pose_data(self, comms, mac, data):
        #verbose_print(comms, self)
        tracker_slot = mac_to_idx(mac)
        packet_metadata = dict(
            getattr(comms, "_current_pose_packet_metadata", None) or {}
        )
        self.poses_recvd[tracker_slot] += 1
        if comms.independent_slam:
            comms.initialized_independent_slam_slots.add(tracker_slot)

        if len(data) == 0x2:
            idx, btns = struct.unpack("<BB", data)
            verbose_print(f"({mac_str(mac)})", hex(idx), "btns:", hex(btns))
            self._maybe_rearm_independent_slam_stream(
                comms,
                tracker_slot,
                current_milli_time(),
            )
            return

        if len(data) != 0x25 and len(data) != 0x27:
            verbose_print("Weird pose data.", len(data))
            hex_dump(data)
            return
        idx, btns, pos, rot, acc, rot_vel, tracking_status = struct.unpack("<BB12s8s6s8sB", data[:0x25])
        self.full_poses_recvd[tracker_slot] += 1
        self.pose_stream_button_only_since_ms[tracker_slot] = 0
        # This is the first byte embedded in the decoded pose payload.  It is
        # distinct from the outer Tracker USB report's source_pose_index_raw.
        packet_metadata["source_pose_data_index_raw"] = int(idx)
        
        # tracking_status = 2 => pose + rot
        # tracking_status = 3 => rot only
        # tracking_status = 4 => pose frozen (lost tracking), rots

        pos_arr = np.frombuffer(pos, dtype=np.float32, count=3)
        raw_rot_xyzw = np.frombuffer(rot, dtype=np.float16, count=4)
        rot_arr = firmware_quaternion_xyzw_to_api_wxyz(raw_rot_xyzw)
        acc_arr = np.frombuffer(acc, dtype=np.float16, count=3)
        rot_vel_arr = np.frombuffer(rot_vel, dtype=np.float16, count=4)
        #verbose_print(f"({mac_str(mac)})", hex(idx), pose_status_to_str(tracking_status), "btns:", hex(btns), "pos:", pos_arr, "rot:", rot_arr, "acc:", acc_arr, "rot_vel:", rot_vel_arr, "time_delta", current_milli_time() - self.pose_time[mac_to_idx(mac)])

        #verbose_print(hex(idx), hex(btns), hex(self.pose_btns[mac_to_idx(mac)]), hex(self.last_pose_btns[mac_to_idx(mac)]))
        self.pose_quat[mac_to_idx(mac)] = rot_arr
        self.pose_pos[mac_to_idx(mac)] = pos_arr
        self.pose_time[mac_to_idx(mac)] = current_milli_time()
        self.pose_tracking_status[mac_to_idx(mac)] = tracking_status

        if btns & 0x80:
            self.last_pose_btns[mac_to_idx(mac)] = self.pose_btns[mac_to_idx(mac)]
            self.pose_btns[mac_to_idx(mac)] = ((btns & 0x7F) << 8) | self.pose_btns[mac_to_idx(mac)] & 0xFF
        else:
            self.last_pose_btns[mac_to_idx(mac)] = self.pose_btns[mac_to_idx(mac)]
            self.pose_btns[mac_to_idx(mac)] = btns | self.pose_btns[mac_to_idx(mac)] & 0xFF00

        if (
            not getattr(comms, "preserve_tracker_profile", False)
            and (self.pose_btns[mac_to_idx(mac)] & 0x100) == 0x100
            and (self.last_pose_btns[mac_to_idx(mac)] & 0x100) == 0x0
        ):# and comms.get_map_state(mac) == MAP_EXIST:
            verbose_print("end map.")
            comms.lambda_end_map(mac)

        self._emit_pose_event(
            idx=idx,
            mac=mac,
            tracking_status=tracking_status,
            buttons=self.pose_btns[mac_to_idx(mac)],
            pos_arr=pos_arr,
            rot_arr=rot_arr,
            acc_arr=acc_arr,
            rot_vel_arr=rot_vel_arr,
            packet_metadata=packet_metadata,
        )

    def _maybe_rearm_independent_slam_stream(self, comms, tracker_slot, now_ms):
        """Retry pose streaming when RF is alive but only button packets arrive.

        This repeats only the idempotent SLAM-host pose-stream command. It never
        enters PairDevice, changes the RF slot/role, clears pairing, or resets
        the tracker's map.
        """

        if (
            not getattr(comms, "independent_slam", False)
            or getattr(comms, "preserve_tracker_profile", False)
        ):
            return False
        first_button_ms = self.pose_stream_button_only_since_ms[tracker_slot]
        if first_button_ms <= 0:
            self.pose_stream_button_only_since_ms[tracker_slot] = now_ms
            return False
        if now_ms - first_button_ms < POSE_STREAM_REARM_DELAY_MS:
            return False
        last_rearm_ms = self.pose_stream_last_rearm_ms[tracker_slot]
        if last_rearm_ms > 0 and now_ms - last_rearm_ms < POSE_STREAM_REARM_INTERVAL_MS:
            return False

        self.pose_stream_last_rearm_ms[tracker_slot] = now_ms
        rearmed = bool(comms.rearm_independent_slam_slot(tracker_slot))
        if rearmed:
            self.pose_stream_rearm_count[tracker_slot] += 1
            verbose_print(
                f"Re-armed independent SLAM pose stream for dongle slot "
                f"{tracker_slot} after button-only RF traffic"
            )
        return rearmed

    def parse_ack(self, comms, device_addr, data_raw):
        data = data_raw.decode("utf-8")
        if data[0:1] == ACK_CATEGORY_CALIB_1:
            data_real = data[1:]
            comms.calib_1 += data_real
            verbose_print(f"   Got CALIB_1 ({mac_str(device_addr)}):", comms.calib_1)
        elif data[0:1] == ACK_CATEGORY_CALIB_2:
            data_real = data[1:]
            comms.calib_2 += data_real
            verbose_print(f"   Got CALIB_2 ({mac_str(device_addr)}):", comms.calib_2)
        elif data[0:1] == ACK_CATEGORY_DEVICE_INFO:
            data_real = data[1:]
            info_key = data_real[:3]
            info_value = data_real[3:].strip()
            device_slot = mac_to_idx(device_addr)
            if (
                0 <= device_slot < len(comms.device_info_by_slot)
                and info_key in {ACK_DEVICE_SN, ACK_SHIP_SN, ACK_PCB_ID, ACK_SKU_ID}
                and info_value
            ):
                comms.device_info_by_slot[device_slot][info_key] = info_value
            verbose_print(
                f"   Got device info ACK ({mac_str(device_addr)}):",
                info_key,
                info_value,
            )

            # Handle post-deviceinfo commands
            if data_real[0:3] == ACK_AZZ:
                if not getattr(comms, "preserve_tracker_profile", False):
                    if comms.is_host(device_addr):
                        #comms.lambda_end_map(device_addr)
                        pass
                    else:
                        comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_COMMAND + f"{RESET_MAP}")
                    comms.send_ack_to(mac_to_idx(device_addr), ACK_FW + "1")
        elif data[0:1] == ACK_CATEGORY_PLAYER:
            data_real = data[1:]
            parts = data_real.split(":")
            idx = int(parts[0])
            args = parts[1]
            

            if idx == LAMBDA_PROP_GET_STATUS:
                args = [int(s) for s in args.split(",")]
                key_id = args[0]
                state = args[1]
                addendum = ""

                if key_id == KEY_RECEIVED_HOST_ED:
                    #if state == 0:
                    #    comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_COMMAND + f"{ASK_ED}")
                    pass
                elif key_id == KEY_RECEIVED_HOST_MAP:
                    if (
                        not getattr(comms, "preserve_tracker_profile", False)
                        and state == 0
                        and (current_milli_time() - comms.last_host_map_ask_ms) > 10000
                        and comms.is_client_connected(device_addr)
                    ):
                        verbose_print("ask for map again")
                        comms.last_host_map_ask_ms = current_milli_time()
                        #comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_COMMAND + f"{RESET_MAP}")
                        #comms.send_ack_to(comms.current_host_id, ACK_LAMBDA_COMMAND + f"{ASK_MAP}") # doesn't work?
                        comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_COMMAND + f"{ASK_MAP}") # doesn't do anything?
                        # TODO: when do we ask for maps?
                        self.bump_map_once[mac_to_idx(device_addr)] = True
                        comms.has_host_map[mac_to_idx(device_addr)] = False
                        pass
                    else:
                        if state > 0:
                            comms.has_host_map[mac_to_idx(device_addr)] = True
                        if self.bump_map_once[mac_to_idx(device_addr)]:
                            #comms.send_ack_to(mac_to_idx(device_addr), ACK_END_MAP)
                            #comms.send_ack_to(mac_to_idx(device_addr), ACK_TRACKING_MODE + "-1")
                            #comms.send_ack_to(mac_to_idx(device_addr), ACK_TRACKING_MODE + "1")
                            self.bump_map_once[mac_to_idx(device_addr)] = False
                        #comms.send_ack_to(mac_to_idx(paired_mac), ACK_END_MAP)
                        #comms.send_ack_to_all(ACK_FW + "1")
                elif key_id == KEY_TRANSMISSION_READY:
                    #comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_COMMAND + f"{RESET_MAP}")
                    #comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_COMMAND + f"{ASK_ED}")
                    a='a'
                elif key_id == KEY_MAP_STATE:
                    addendum = f"({map_status_to_str(state)})"

                    self.handle_map_state(comms, device_addr, state)
                elif key_id == KEY_CURRENT_TRACKING_STATE:
                    addendum = f"({pose_status_to_str(state)})"

                verbose_print(f"   Status returned for SLAM key {slam_key_to_str(key_id)} ({mac_str(device_addr)}): {state} {addendum}")

            else:
                verbose_print(f"   Got PLAYER ACK ({mac_str(device_addr)}):", f"CMD{idx}", args)
        elif data[0:2] == ACK_LAMBDA_PROPERTY:
            data_real = data[2:]
            verbose_print(f"   Got LP ACK ({mac_str(device_addr)}):", data_real)
        elif data[0:2] == ACK_LAMBDA_STATUS:
            data_real = data[2:]
            a, b, c = [int(s) for s in data_real.split(",")]
            verbose_print(f"   Got LAMBDA_STATUS ACK ({mac_str(device_addr)}): {a},{b},{c}")
            if not getattr(comms, "preserve_tracker_profile", False):
                comms.send_ack_to_all(ACK_FW + "0")
            if b != 2:
                #verbose_print("ask for host map.")
                #comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_COMMAND + f"{ASK_ED}")
                #comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_COMMAND + f"{ASK_MAP}")
                #comms.send_ack_to(mac_to_idx(device_addr), ACK_LAMBDA_COMMAND + f"{KF_SYNC}")
                pass
                
        elif data[0:4] == ACK_ERROR_CODE:
            data_real = data[4:]
            verbose_print(f"   Got ERROR ({mac_str(device_addr)}):", data_real)
        elif data[0:2] == ACK_WIFI_HOST_SSID:
            data_real = data[2:]
            ssid, passwd, freq = data_real.split(",")
            verbose_print(f"   Got WIFI_HOST_SSID ACK ({mac_str(device_addr)}): freq={freq}")

            comms.host_ssid = ssid
            comms.host_passwd = passwd
            comms.host_freq = freq
        elif data[0:2] == ACK_WIFI_SSID_PASS:
            verbose_print(f"   Got WIFI_SSID ACK ({mac_str(device_addr)})")

            if not getattr(comms, "preserve_tracker_profile", False):
                comms.wifi_set_ssid(mac_to_idx(device_addr), comms.host_ssid)
                comms.wifi_set_password(mac_to_idx(device_addr), comms.host_passwd)
                #comms.wifi_set_ssid_password(mac_to_idx(device_addr), comms.host_ssid, comms.host_passwd)
                comms.wifi_set_freq(mac_to_idx(device_addr), comms.host_freq)
                comms.wifi_set_country(mac_to_idx(device_addr), comms.wifi_info["country"])
        elif data[0:2] == ACK_WIFI_CONNECT:
            ret = int(data[2:])
            verbose_print(f"   Got WIFI_CONNECT ACK ({mac_str(device_addr)}): {ret}")
            comms.connected_to_host[mac_to_idx(device_addr)] = (ret > 0)
            

        elif data[0:2] == ACK_MAP_STATUS:
            data_real = data[2:]
            status = [int(s) for s in data_real.split(",")]

            self.handle_map_state(comms, device_addr, status[1])

            verbose_print(f"   Got MAP_STATUS ({mac_str(device_addr)}):", status, f"({map_status_to_str(status[1])})")
            #comms.send_ack_to_all(ACK_END_MAP)

            # Initial map status:
            # Got MAP_STATUS: -1,10
            # Got MAP_STATUS: 0,10
            # Got MAP_STATUS: 0,3

            # Losing tracking?
            # Got LP ACK: 1,0,1
            # Got MAP_STATUS: -1,0
            # Got MAP_STATUS: -1,1

            # Got MAP_STATUS: 0,6 = mapped and tracking
        elif data[0:3] == ACK_POWER_OFF:
            verbose_print(f".  Got POWER_OFF. ({mac_str(device_addr)})")
            comms.handle_disconnected(mac_to_idx(device_addr))
        elif data[0:3] == ACK_RESET:
            verbose_print(f".  Got RESET ({mac_str(device_addr)}).")
            comms.handle_disconnected(mac_to_idx(device_addr))
        else:
            verbose_print(f"   Got ACK ({mac_str(device_addr)}):", data, "(", data_raw, ")")
        verbose_print("")


    def get_map_state(self, device_addr):
        return self.tracker_map_state[mac_to_idx(device_addr)]

    def get_pos(self, idx=0):
        return np.array(self.pose_pos[idx])

    def get_rot(self, idx=0):
        return np.array(self.pose_quat[idx])

    def get_pose(self, idx=0):
        return {
            "position": np.array(self.pose_pos[idx], dtype=np.float32),
            "rotation": np.array(self.pose_quat[idx], dtype=np.float32),
            "buttons": int(self.pose_btns[idx]),
            "tracking_status": int(self.pose_tracking_status[idx]),
            "timestamp_ms": int(self.pose_time[idx]),
        }

    def do_loop(self):
        self.comms.do_loop()

    def _emit_pose_event(
        self,
        idx,
        mac,
        tracking_status,
        buttons,
        pos_arr,
        rot_arr,
        acc_arr,
        rot_vel_arr,
        packet_metadata=None,
    ):
        if not self.pose_listeners:
            return

        tracker_slot = mac_to_idx(mac)
        if tracker_slot not in self._active_tracker_slots:
            self._active_tracker_slots.append(tracker_slot)
        contiguous_index = self._active_tracker_slots.index(tracker_slot)

        device_info = {}
        if hasattr(self.comms, "device_info_by_slot"):
            device_info = dict(self.comms.device_info_by_slot[tracker_slot])
        hardware_serial = (
            device_info.get(ACK_DEVICE_SN)
            or device_info.get(ACK_SHIP_SN)
            or device_info.get(ACK_PCB_ID)
            or ""
        )

        packet_metadata = dict(packet_metadata or {})
        sample = {
            "tracker_index": contiguous_index,
            "mac": bytes(mac),
            "hardware_serial": hardware_serial,
            "device_info": device_info,
            "buttons": buttons,
            "tracking_status": tracking_status,
            "timestamp_ms": self.pose_time[tracker_slot],
            "position": np.array(pos_arr, dtype=np.float32),
            "rotation": np.array(rot_arr, dtype=np.float32),
            "acceleration": np.array(acc_arr, dtype=np.float32),
            "angular_velocity": np.array(rot_vel_arr, dtype=np.float32),
            "hid_read_host_realtime_ns": packet_metadata.get(
                "hid_read_host_realtime_ns"
            ),
            "hid_read_host_monotonic_ns": packet_metadata.get(
                "hid_read_host_monotonic_ns"
            ),
            "hid_read_host_monotonic_raw_ns": packet_metadata.get(
                "hid_read_host_monotonic_raw_ns"
            ),
            "source_packet_index_raw": packet_metadata.get(
                "source_packet_index_raw"
            ),
            "source_hmd_us_raw": packet_metadata.get("source_hmd_us_raw"),
            "source_pose_index_raw": packet_metadata.get(
                "source_pose_index_raw"
            ),
            "source_pose_data_index_raw": packet_metadata.get(
                "source_pose_data_index_raw"
            ),
            "source_pose_timestamp_raw": packet_metadata.get(
                "source_pose_timestamp_raw"
            ),
            "source_netsync_raw": tuple(
                tuple(pair) for pair in packet_metadata.get("source_netsync_raw", ())
            ),
        }

        for listener in list(self.pose_listeners):
            try:
                listener(sample)
            except Exception as exc:
                verbose_print(f"Pose listener raised {exc}")

if __name__ == '__main__':
    trackers = ViveTrackerGroup()
    #trackers = ViveTrackerGroup(mode="TRACKER_USB")

    while True:
        trackers.do_loop()


# What USB-HID PCVR does internally, could be useful for BTLE?
'''
              send_horus_cmd(0,0); // HORUS_CMD_POWER 0
              send_horus_cmd(0xb,0xffff); // HORUS_CMD_UPDATE_DEVICE_ID
              send_horus_cmd(0xc,bVar9); // HORUS_CMD_SET_TRACKING_MODE
              if (command_ == 0xa101) { // ocvr
                uVar24 = 8;
              }
              else {
                uVar24 = 9;
              }
              idk_pcvr_mode(0,uVar24); // HORUS_CMD_POWER, 
'''
