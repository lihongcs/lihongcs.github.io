# VIVE Ultimate Tracker adapter

This adapter reads Tracker poses over USB HID or the wireless dongle. The GenUMI distribution includes the host-side modules used by DataCap and the `scripts/stream_poses.py` diagnostic. It is based on [pyvut](https://github.com/nijkah/pyvut) by nijkah and pitin, which builds on [vive_ultimate_tracker_re](https://github.com/shinyquagsire23/vive_ultimate_tracker_re).

Follow [DataCap installation](../datacap/README.md) for system setup. The Tracker must first have an available map. Initial map construction can be performed in VIVE Streaming Hub and SteamVR on Windows if needed.

DataCap reads `~/.config/instadatacap/wifi_info.json` by default. To use the pyvut API directly, pass that file as `wifi_info_path` or create `wifi_info.json` alongside `tracker_core.py`. Fill in the values from your own hardware configuration using the provided example. For an existing Tracker profile, pass `preserve_tracker_profile=True` and `enable_pairing_on_start=False`.
