# GenUMI for Ubuntu

DataCap starts and stops recording, marks demonstrations, and saves camera and Tracker timestamps in a session folder. DataProcess converts a completed session for robot learning. Use the optional iOS project for standalone X5 capture and media transfer.

- [DataCap installation and capture](datacap/README.md)
- [DataProcess and dataset export](dataprocess/README.md)
