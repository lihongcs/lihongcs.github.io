# GenUMI hardware for Flexiv Grav GN-01

GenUMI is an Insta360-based handheld Universal Manipulation Interface. This
archive contains editable SolidWorks parts and subassemblies for the handheld
mechanism designed to match the Flexiv Grav GN-01 gripper.

## Open the CAD

Extract the archive and keep the CAD files together. Start from
`body_new_version.SLDASM` for the handheld body. The
`gear_left_bearing.SLDASM` and `gear_right_bearing.SLDASM` drive
subassemblies and `fingertip_merged_left.SLDASM` and
`fingertip_merged_right.SLDASM` fingertip subassemblies are separate entry
points. The supplied files include the Insta360 mount, finger linkages and
TPU fingertip designs.

- The gear subassemblies reference the SolidWorks Toolbox
  `spur gear_am.sldprt` in metric module 2 configurations. The recorded
  left gear has 33 teeth and the right gear has 32 teeth. Both use a 20-degree
  pressure angle and 10 mm face width.
- The right fingertip subassembly references `9dtact_base_enhanced.SLDPRT`,
  which is outside this source snapshot.
- The VIVE bracket design references [DexCap hardware](https://dex-cap.github.io/).

## Reference files omitted

The full `instaumi.SLDASM` assembly includes embedded VIVE Ultimate Tracker
geometry. It is held with the camera and tracker reference CAD. Use the
subassemblies above to inspect the project hardware.

- `instaumi.SLDASM`
- `insta360x5_solidworks_lite_100k.SLDPRT`
- `insta360x5_step_export_10k.SLDPRT`
- `insta360x5_step_export_10k.stl`
- `Ultimate Tracker_1115.obj`
- `Ultimate Tracker_1115.stp`

## Verification and license

This is a native CAD source snapshot. The ZIP and its file contents were
checked. Assembly rebuilds and fabrication were unverified. SolidWorks may
request that you relink external references recorded with original file paths.

Project-owned GenUMI hardware CAD follows the BSD 3-Clause license in
`LICENSE`. Third-party material retains its upstream terms.
