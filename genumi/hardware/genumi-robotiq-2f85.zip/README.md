# GenUMI hardware for Robotiq 2F-85

GenUMI is an Insta360-based handheld Universal Manipulation Interface. This
archive contains editable SolidWorks files for the handheld body, connector
and drive gear design for the Robotiq 2F-85 variant. A complete handheld
gripper build requires the Robotiq-derived finger linkage geometry described
below.

## Open the CAD

Extract the archive and keep the CAD files together. Open
`body_new_version.SLDASM` for the handheld body or `gear.SLDASM` for
the gear subassembly. `connector.SLDPRT` is the variant's standalone
connector.

- The body subassembly references `DexCap_D435_Vive_Bracket_v2.SLDPRT`.
  This bracket is available in the adjacent GenUMI Flexiv GN-01 CAD archive.
- The drive gear references the SolidWorks Toolbox `spur gear_am.sldprt`
  in a metric module 1.25, 20-tooth configuration with a 20-degree pressure
  angle and 10 mm face width.
- Robotiq provides manufacturer files through its
  [CAD and documentation guide](https://blog.robotiq.com/knowledge/finding-robotiq-cad-files-manuals-and-certificates).

## Reference files omitted

The source folder holds commercial comparison models and finger parts based on
Robotiq CAD. Their source and printable exports, together with the three
drive subassemblies that incorporate those parts, are held outside this
archive.

- `2F85_Opened_20190924-Sep-06-2024-02-25-46-4707-PM.step`
- `2F85-CLOSED_20181108-Sep-06-2024-02-25-56-3542-PM.step`
- `Defeatured 2F-85 full assembly.sldasm`
- `2F distal.SLDPRT`, `2F distal.STL`
- `2F membrure.SLDPRT`, `2F membrure.STL`
- `2F-85 barre.SLDPRT`, `2F-85 barre.STL`
- `2F-85 pad.SLDPRT`, `2F-85 pad.STL`
- `2F-85 proximal.SLDPRT`, `2F-85 proximal.STL`
- `2F-85 proximal_righthand_leftfinger.SLDPRT`
- `gear_priximal_right.SLDASM`
- `gear_priximal_righthand_left_finger.SLDASM`
- `gear_proximal.SLDASM`

## Verification and license

This is a native CAD source snapshot. The ZIP and its file contents were
checked. Assembly rebuilds and fabrication were unverified. SolidWorks may
request that you relink external references recorded with original file paths.

Project-owned GenUMI hardware CAD follows the BSD 3-Clause license in
`LICENSE`. Third-party material retains its upstream terms.
