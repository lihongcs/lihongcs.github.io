# GenUMI STEP files for Flexiv Grav GN-01

The supplied HTC tracker is seated on its original bracket. The X5 scan is scaled to its published dimensions. The eight pivot screws enter from the top, with flush 90° heads and locknuts underneath.

The archive contains neutral STEP geometry. The GenUMI project designs follow the BSD 3-Clause license in `LICENSE`. Third-party material follows its upstream terms.
