# GenUMI STEP files for Flexiv Grav GN-01

The updated camera interface uses a GenUMI spacer and a purchased Insta360 Magnetic Quick Release Mount. The 3D model shows the GenUMI hardware.

The archive contains neutral STEP geometry. The GenUMI project designs follow the BSD 3-Clause license in `LICENSE`. Third-party material follows its upstream terms.
