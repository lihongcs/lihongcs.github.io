# GenUMI STEP files for Flexiv Grav GN-01

The assembly includes the quick-release spacer and 8 shoulder-screw pivot sets. Clearance was checked in the saved pose. The right inner pivot uses a custom stepped shoulder screw and reducer bushing.

The archive contains neutral STEP geometry. The GenUMI project designs follow the BSD 3-Clause license in `LICENSE`. Third-party material follows its upstream terms.
