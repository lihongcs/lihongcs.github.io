# GenUMI STEP files for Robotiq 2F-85

The viewer shows the original jaw components in the reconstructed Robotiq assembly, with the supplied X5 and VIVE Ultimate Tracker geometry. The complete STEP includes the camera, tracker and reconstructed jaw linkage. 6 pivot screws have flush top-entry heads. Both frame-to-bar and both outer distal pivots retain their previous hardware.

The archive contains neutral STEP geometry. The GenUMI project designs follow the BSD 3-Clause license in `LICENSE`. Third-party material follows its upstream terms.
