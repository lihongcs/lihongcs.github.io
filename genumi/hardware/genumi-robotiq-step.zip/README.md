# GenUMI STEP files for Robotiq 2F-85

The complete assembly includes the supplied camera and tracker geometry and the original jaw layout with ring-free outer and proximal finger links. All ten screw ends are flush with the underside of their nuts. Six top heads are countersunk. The four frame-to-bar and outer distal pivots have socket heads.

The archive contains neutral STEP geometry. The GenUMI project designs follow the BSD 3-Clause license in `LICENSE`. Third-party material follows its upstream terms.
