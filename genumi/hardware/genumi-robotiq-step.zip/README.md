# GenUMI STEP files for Robotiq 2F-85

This view shows the GenUMI body and connectors in the reconstructed assembly. The commercial finger geometry and Toolbox gear are available from their respective suppliers.

The archive contains neutral STEP geometry. The GenUMI project designs follow the BSD 3-Clause license in `LICENSE`. Third-party material follows its upstream terms.
