# GenUMI STEP files for Robotiq 2F-85

The GenUMI body, connectors and four chassis pivot fastener sets are shown. The finger geometry and Toolbox gear are supplied separately. Fit was checked in the saved pose.

The archive contains neutral STEP geometry. The GenUMI project designs follow the BSD 3-Clause license in `LICENSE`. Third-party material follows its upstream terms.
