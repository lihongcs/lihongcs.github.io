# GenUMI STL files for Flexiv Grav GN-01

The supplied HTC tracker is seated on its original bracket. The X5 scan is scaled to its published dimensions. All eight countersunk screws are flush at the top and finish at the underside of the locknuts.

The archive contains neutral STL geometry. The GenUMI project designs follow the BSD 3-Clause license in `LICENSE`. Third-party material follows its upstream terms.

The STL files use millimeter coordinates. Assembly STLs preserve the assembled placements and include multiple parts. Use the individual files when printing individual components.
