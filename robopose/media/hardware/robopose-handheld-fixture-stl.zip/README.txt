RoboPose fixture CAD files

Stock SolidWorks BReps for the printed tracking rack and its handle. The assembly STL preserves the grip contact position. The two straps and mounted tracker bodies can be seen in the interactive preview.

All coordinates are in millimeters. Printable fixtures are derived from the project OmniIMU folder. Devices and arm CAD are excluded from the STL packages.
