RoboPose robot-mounted fixture CAD
The tracker plate is shared with the handheld setup. The original fixed Flexiv adapter replaces the handheld grip at the same four mounting positions. The complete adapter combines the native grip_flexiv base and half clamp as exported from flexiv_imu.SLDASM.
All models use millimeters. The combined STL uses the handheld rack coordinate frame to preserve interface alignment.
The package contains the project-authored hardware geometry. The robot, gripper, commercial trackers, controller shell, and wiring are visual references in the viewer.
