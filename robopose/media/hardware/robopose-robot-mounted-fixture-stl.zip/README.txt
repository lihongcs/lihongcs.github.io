RoboPose fixture CAD files

Stock SolidWorks BReps for the GN-01 tracker clamp, phone cradle, and RoboBaton standoff. The two photo-derived tracker and Quest support meshes shown in the interactive preview are fit references only.

All coordinates are in millimeters. Printable fixtures are derived from the project OmniIMU folder. Devices and arm CAD are excluded from the STL packages.
