# GelSlim Mini

The Parts/ directory contains the individual, English-named STEP parts used in the public CAD release. The project page provides the corresponding assembly STEP. Where included, geometry for commercial electronics shows the space they occupy.

Project and assembly downloads
https://lihongcs.github.io/gelslim-mini/

Related upstream hardware

- [GelSlim 4.0 optics and lighting](https://github.com/MMintLab/gelslim_hardware)
- [9DTact camera reference](https://github.com/linchangyi1/9DTact)

The included BSD 3-Clause license applies to the CAD authored for this project. Upstream hardware is governed by its source repository's license.
