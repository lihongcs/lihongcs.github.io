# GelSlim Mini

The Parts/ directory contains the individual, English-named STEP parts used in the public CAD release. The project page provides the corresponding assembly STEP. Commercial components use independently modeled exterior geometry for fit review.

The LED driver mechanical PCB reproduces the original ECAD substrate. Component bodies and flex routing are modeled for fit review. The derivative LED driver and flex STEP files use the included GelSlim CC BY-NC 4.0 terms. These retain interference with the prototype enclosure.

Project and assembly downloads
https://lihongcs.github.io/gelslim-mini/

Related upstream hardware

- [GelSlim 4.0 optics and lighting](https://github.com/MMintLab/gelslim_hardware)
- [9DTact camera reference](https://github.com/linchangyi1/9DTact)
- [GelSlim 3.0 electrical files (CC BY-NC 4.0)](https://github.com/mcubelab/gelslim/tree/51953e685e923c0c1f6e24ff031f22bb49b4bf19/Hardware/Electrical)

The included BSD 3-Clause license applies to the CAD authored for this project. Upstream hardware is governed by its source repository's license.
