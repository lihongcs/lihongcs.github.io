# GelSlim Mini

This archive contains editable SolidWorks part files authored for this project. The published assembly STEP includes the full public assembly and fit references for the vendor components. The SolidWorks part files are grouped under Parts/.

Project and assembly downloads
https://lihongcs.github.io/gelslim-mini/

Related upstream hardware

- [GelSlim 4.0 optics and lighting](https://github.com/MMintLab/gelslim_hardware)
- [9DTact camera reference](https://github.com/linchangyi1/9DTact)

The included BSD 3-Clause license applies to the CAD authored for this project. Upstream hardware is governed by its source repository's license.
