# AetheRock Parallel Gripper V1 SolidWorks Source

The v1_final_version directory contains the original SolidWorks parts. The source set has no native top-level assembly. The interactive model and assembly STL provide reconstructed reference placement.

The fabrication STL release adds the rail, optics and frame mounting clearances documented in its parts package. This archive preserves the original CAD geometry.

The supplied BSD 3-Clause license applies to project-authored files. Vendor product documentation and CAD retain their existing terms.
