# HandCap PCB design sources

These editable project exports come from the original designs in JLCEDA Pro. The files were exported on 2026-11-14 and retain the design data in their original JLCEDA project formats. PCB sizes below are measured from the corresponding STEP board solids.

| Original project | Source | Board body | Installation |
| --- | --- | --- | --- |
| `angle`, PCB1 | [V2 project](as5600-angle-encoder.epro) | 17.755 × 18.644 × 1.6 mm | Interface daughterboard above the AS5600 donor PCB. CN1 is a 4-position, 2.5 mm top-entry XH header. The AS5600 sensing IC is on the donor board. In the assembly STEP, U1 and U2 remain electrically represented by the original design source. Their full library connector bodies are omitted to reflect the soldered donor connections in the photographed prototype. |
| `force_pcb`, PCB1 | [V2 project](force-adc-board.epro) | 15.723 × 18.009 × 1.6 mm | ADC daughterboard with TI ADS1110A0IDBVR at U1 and the four-position cable header at U2. It receives the analog signal from the blue force-sensitive-resistor converter. The installed version uses exposed/bent contacts on the converter side. The assembly STEP keeps U2 and the signal components and excludes the library bodies for U3 and U4 and two detached outline fragments. |
| `orangepi_transfer`, PCB1 | [V3 project](orange-pi-4-pro-gpio-interconnect.epro2) | 19.279 × 61.570 × 1.6 mm | GPIO interconnect above the Orange Pi 4 Pro. Its 2 × 20 header and five cable connectors are represented in the assembly STEP. The photographed 40-pin row appears as solder joints on the top face with the board-to-board connection below. The physical plug and lead protrusion vary with connector and cable selection. |

The `force_pcb_pin_connector` project has a different 21.438 × 18.771 mm PCB with two shrouded headers. The `orangepi_transfer_5pro` project is a separate revision. The assembly uses `force_pcb` and `orangepi_transfer` based on their closer match to the photographed hardware.

The JLCEDA projects are the source for footprints, copper, pads, and net assignments. Assembly STEP geometry is intended for mechanical fit. Actual soldered leads, fitted cable plugs, and the wire bend clearance still require physical verification.

The included BSD 3-Clause license covers the original HandCap PCB design. Referenced commercial part libraries remain subject to their respective terms.
