# AetheRock Parallel Gripper

The original parallel design carries the revised Hikrobot camera mount, paired GelSlim Mini sensors, and fingertip force sensing. The combined STL includes fit references for electronics and wiring. The browser demonstrates rail translation. The STL geometry uses millimetres.

The assembly STL contains positioned components for inspection and fit reference. Its components can have intentional contacts and overlaps. Individual parts are in Parts/ in their own local coordinate systems. Use the named structural parts for fabrication. The package may also include part geometry for components such as optical surfaces, circuit boards or fasteners.

The fitted jaw and trigger parts include 0.10 mm relief along the modeled 7 × 5 mm rail sweep and local clearance for the GelSlim optical shrouds. The tactile back covers clear the native jaw material and make room for the OV5647 optics. The fitted frame clears the native forearm support. The original SolidWorks files preserve the starting geometry for these parts.

Purchased camera electronics and the VIVE tracker are mechanical fit references. The assembly includes envelope geometry for the trackers and electronic modules. They are listed below and have no individual files in this package. The BSD 3-Clause license applies to project-authored files.

- 10 mm Diffused RGB LED Module (1)
- AS5600 Angle Encoder Custom PCB (1)
- AS5600 Carrier Board (1)
- AS5600 Encoder XH2.54 Ribbon Cable (1)
- AS5600 IC Package Reference (1)
- Blue and White Ribbon Protective Sleeve (1)
- Controller Tray (1)
- Hikrobot MV CB060 Camera (1)
- Large Tactile Pushbutton Module (1)
- Left FSR Amplifier PCB (1)
- Left Flexible Matrix FSR 22 mm (1)
- Left Force ADC Board to Board Header (1)
- Left Force ADC XH2.54 Ribbon Cable (1)
- Left Force PCB Mount Screw (1)
- Left Force Sensor ADC Adapter (1)
- Left OV5647 Camera FPC (1)
- Left OV5647 Fisheye Camera (1)
- Left OV5647 USB Adapter PCB (1)
- Left Soldered FSR Lead Reference (1)
- Magnet Bondline 0p10 Reference (1)
- Magnet D6 x 2p5 Diametric (1)
- Orange Pi 4 Pro Custom GPIO PCB (1)
- Orange Pi 4 Pro Wristward Ports (1)
- PCB Spacer OD5p8 ID3p5 L3p5 (4)
- Pushbutton XH2.54 Soldered Ribbon Cable (1)
- RGB LED XH2.54 Soldered Ribbon Cable (1)
- Right FSR Amplifier PCB (1)
- Right Flexible Matrix FSR 22 mm (1)
- Right Force ADC Board to Board Header (1)
- Right Force ADC XH2.54 Ribbon Cable (1)
- Right Force PCB Mount Screw (1)
- Right Force Sensor ADC Adapter (1)
- Right OV5647 Camera FPC (1)
- Right OV5647 Fisheye Camera (1)
- Right OV5647 USB Adapter PCB (1)
- Right Soldered FSR Lead Reference (1)
- Upper Arm Articulation (1)
- Upper Arm Strap (1)
- VIVE Ultimate Tracker (1)
