# AetheRock Parallel Gripper V2 SolidWorks Source

Open combined_forcetacumi.SLDASM in SolidWorks. The assembly and its original parts retain their native names and are stored together so SolidWorks can resolve the component references. This is the original mechanical source and keeps its hidden parts and embedded virtual bodies. The interactive model and assembled STL also show fitted electronics and optical stack references.

The saved configuration used by combined_forcetacumi.SLDASM does not use the external glovemount_from_arcap.SLDPRT body. Opening arm_main_combined.SLDASM in its separate default configuration can prompt for that optional upstream body. Switch to the configuration used by the top-level assembly to inspect the supplied components.

Virtual components stored inside their owning assembly

- 零件1^combined_forcetacumi.SLDPRT
- 零件2^arm_main_combined.SLDPRT

The fabrication STL release adds the rail, optics and frame mounting clearances documented in its parts package. This archive preserves the original CAD geometry.

The supplied BSD 3-Clause license applies to project-authored files. Vendor product documentation and CAD retain their existing terms.
