# AetheRock human forearm and hand reference pose

This is original geometry generated for this mechanical review from smooth implicit surfaces. It is not a scan, a medical anatomical model, a measurement of the device user, or an approved ergonomic fit. No third-party human mesh or skin texture is included.

The model includes one right forearm, a hand, and a short upper-arm transition. The wrist is close to x = 0, y = -73.5 mm, z = -24 mm in the AetheRock wearable assembly. Coordinates are millimeters. +X is across the arm, +Y points outward toward the electronics, and +Z points toward the gripper. The reference can be placed in wearable CAD at the shared origin with no rotation or scale change.

## Files
- Human-Forearm-and-Hand-Pose.stl is the watertight mesh for CAD overlay (171,088 triangles).
- Human-Forearm-and-Hand-Pose.ply preserves per-vertex skin/nail color.
- Human-Forearm-and-Hand-Pose-Display.ply is the watertight display version (30,000 triangles).
- generate.py reconstructs the full-size mesh. make_display.py creates the reduced version. Install Python, NumPy, and VTK and run both scripts from the extracted package directory. Both scripts write beside themselves.

The pose depicts one example grasp. Subject-specific forearm size, finger positions, hand/glove clearances, and complete clamp and band range must be established separately.
