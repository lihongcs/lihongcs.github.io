# AetheRock operator hand and forearm

The right-hand pose brings the thumb and index into the accessible arcs of opposite circular supports. The middle, ring, and little fingers curl along the index side. The central area of each circular support remains occupied by the installed sensing stack. The hand is a reference mesh distinct from the wearable hardware assembly. Millimeter coordinates share the parent assembly origin. +Z points toward the gripper and +Y toward the electronics.

The pose was modeled from the assembly and photographs. It describes one grip configuration and does not establish glove fit, user-specific anthropometry, or available motion throughout the mechanism's travel.

## Files

- Human-Forearm-and-Hand-Pose.stl contains the watertight CAD overlay mesh (179,720 triangles).
- Human-Forearm-and-Hand-Pose.ply includes vertex colors.
- Human-Forearm-and-Hand-Pose-Display.ply is the lower-density viewer mesh (30,000 triangles).
- generate.py creates the full-resolution mesh.
- make_display.py creates the viewer mesh.

Install NumPy and VTK for Python to run the scripts. Both scripts write beside themselves.
