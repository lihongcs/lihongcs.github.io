# AetheRock operator hand and forearm

The right-hand pose places its thumb on the left fingertip support's trigger hook and its index finger on the opposite trigger hook. Middle, ring, and little fingers curl inward for support. The hand is a reference mesh distinct from the wearable hardware assembly. Millimeter coordinates share the parent assembly origin. +Z points toward the gripper and +Y toward the electronics.

The pose was modeled from the assembly and photographs. It describes one grip configuration and does not establish glove fit, user-specific anthropometry, or available motion throughout the mechanism's travel.

## Files

- Human-Forearm-and-Hand-Pose.stl contains the watertight CAD overlay mesh (167,056 triangles).
- Human-Forearm-and-Hand-Pose.ply includes vertex colors.
- Human-Forearm-and-Hand-Pose-Display.ply is the lower-density viewer mesh (30,000 triangles).
- generate.py creates the full-resolution mesh.
- make_display.py creates the viewer mesh.

Install NumPy and VTK for Python to run the scripts. Both scripts write beside themselves.
