from pathlib import Path
from collections import Counter
import numpy as np
import vtk
from vtk.util.numpy_support import numpy_to_vtk, vtk_to_numpy

support = Path(__file__).resolve().parent
step = 1.15
ox, oy, oz = -83.,-145.,-288.
x,y,z = [np.arange(a,b,step,dtype=np.float32) for a,b in [(ox,65),(oy,-18),(oz,180)]]
X,Y,Z = np.ix_(x,y,z)
field=np.full((len(x),len(y),len(z)),15,dtype=np.float32)


def union(v,smoothing):
    global field
    if smoothing:
        amount=np.maximum(smoothing-np.abs(field-v),0)/smoothing
        field=np.minimum(field,v)-amount**2*(smoothing*.25)
    else:
        field=np.minimum(field,v)


def ellipsoid(center,radii,axes=None,k=3.5):
    axes=np.eye(3) if axes is None else axes
    D=(X-center[0],Y-center[1],Z-center[2])
    Q=[sum(v*d for v,d in zip(axis,D)) for axis in axes]
    value=np.sqrt(sum((q/r)**2 for q,r in zip(Q,radii)))-1
    union(value*min(radii),k)


def monotone(q, knots):
    points=np.array(knots,float)
    values=points[:,0]
    dx=np.diff(values)
    slope=np.diff(points[:,1:],axis=0)/dx[:,None]
    tang=np.empty_like(points[:,1:])
    tang[0]=slope[0]
    tang[-1]=slope[-1]
    tang[1:-1]=(slope[:-1]+slope[1:])*.5
    blended=[]
    u=np.clip(np.searchsorted(values,q,side='right')-1,0,len(values)-2)
    t=np.clip((q-values[u])/dx[u],0,1)
    for j in range(tang.shape[1]):
        d=dx[u]
        p0=points[u,1+j];p1=points[u+1,1+j]
        m0=tang[u,j];m1=tang[u+1,j]
        blended.append(((2*t-3)*t*t+1)*p0+((t-2)*t+1)*t*m0*d+(-2*t+3)*t*t*p1+(t-1)*t*t*m1*d)
    return blended


knots=[
    (-281,1,-58,1,1,0),(-273,1,-57,30,28,-2),(-248,1,-55,37.3,28.25,-4),
    (-225,0,-52,39.1,28.25,-4),(-201,-.1,-50.9,40.05,28.5,-1),
    (-180,0,-57,34,25,1),(-158,-1,-68,30,23,1),(-138,-1,-72,32,24,2),
    (-111,-1,-73.5,33.5,24,3),(-82,0,-75,31,22.7,6),
    (-55,0,-74.5,28.6,20.1,6),(-38,.4,-77.0,27.3,20.0,5),
    (-20,1,-82,25.5,17.4,6),(1,4,-87.0,24.4,16.9,8),
    (18,11,-95,25,15.0,9),(37,16,-102,27.5,14.8,9),
    (57,22,-106,31.5,15.6,9),(75,27,-111,32,14.0,7),
    (90,36,-109,23.5,10.2,6),(97,45,-105,19.5,9.0,5),
    (103,46.5,-101.5,11.5,6.3,4),(109,46,-101.5,3,3,4),
]
cx,cy,rx,ry,theta=monotone(z,knots)
reflection = np.clip((z+110.)/100.,0.,1.)
cx *= 1-2*reflection
theta *= 1-2*reflection
rot=theta[None,None,:]*(np.pi/180)
x0=X-cx[None,None,:]
y0=Y-cy[None,None,:]
xp=np.cos(rot)*x0+np.sin(rot)*y0
yp=-np.sin(rot)*x0+np.cos(rot)*y0
base=(np.sqrt((xp/rx[None,None,:])**2+(yp/ry[None,None,:])**2)-1)*np.minimum(rx,ry)[None,None,:]
outside=np.maximum(knots[0][0]-Z,Z-knots[-1][0])
union(np.maximum(base,outside),0)

# Palm contour, thenar and hypothenar pads, metacarpal head and wrist bones.
ellipsoid((-2,-111,67),(17,12.8,27),k=5)
ellipsoid((-35,-113,66),(16,11.7,28),k=4.9)
ellipsoid((-10,-105,82),(10,7.1,14),k=3.5)
ellipsoid((-38,-103,89),(12,6.5,13),k=3.6)
ellipsoid((-21,-87,0),(4.7,5.0,8.7),k=3.2)
ellipsoid((15,-83,0),(4.8,4.6,8.5),k=2.9)


def segment(p0,p1,r0,r1,k,taper=1.0):
    p=np.asarray(p0)
    d=np.asarray(p1)-p
    t=np.clip(((X-p[0])*d[0]+(Y-p[1])*d[1]+(Z-p[2])*d[2])/np.dot(d,d),0,1)
    dist=np.sqrt((X-p[0]-t*d[0])**2+(Y-p[1]-t*d[1])**2+(Z-p[2]-t*d[2])**2)
    union((dist-r0-(r1-r0)*t)*taper,k)


def digit(name,nodes,radii):
    last=len(nodes)-2
    for i,(a,b) in enumerate(zip(nodes,nodes[1:])):
        if i!=last or name not in ('thumb','index'):
            segment(a,b,radii[i],radii[i+1],(2.4,1.55,1.1,1.0)[min(i,3)])
            continue
        # Flatten the distal pulp only across the narrow recess, maintaining the
        # fingertip's oval pad dimensions in its other two axes.
        center=np.array(a,float)
        direction=np.array(b,float)-center
        scaled=direction/np.array([.76,1.0,1.13])
        delta=((X-center[0])/.76,Y-center[1],(Z-center[2])/1.13)
        t=np.clip(sum(v*d for v,d in zip(scaled,delta))/np.dot(scaled,scaled),0,1)
        dist=np.sqrt(sum((d-t*v)**2 for v,d in zip(scaled,delta)))
        union((dist-radii[i]-(radii[i+1]-radii[i])*t)*.76,.85)


# The thenar side lies along the radial index metacarpal edge at low X.
# The thumb crosses out to the opposite jaw. The four fingers share the index-side palm.
fingers={
 'thumb':([(-2,-105,63),(-23,-106,86),(-47,-109,104),(-47,-101,126),(-44.9,-89.2,145),(-43.0,-76.8,156),(-43.0,-69.5,158.7)],[11.7,9.3,7.6,6.7,5.8,4.75,4.6]),
 'index':([(11,-107,90),(14,-101,103),(15,-98,115),(26,-99,122),(38,-100,129),(42.9,-89,144),(43.1,-77,156),(43.1,-69.0,159)],[8.6,7.7,7.1,6.8,6.6,5.8,4.55,4.2]),
 'middle':([(43,-97,99),(51,-101,117),(55,-103,133),(56,-92,145),(53,-88,149)],[8.15,7.35,6.55,5.65,4.95]),
 'ring':([(50,-101,96),(59,-109,117),(63,-107,130),(65,-98.5,138),(58,-94,137)],[7.65,6.9,6.0,5.1,4.6]),
 'little':([(56,-106,89),(65,-114,108),(70,-110,120),(70,-100,126),(63.5,-96,124)],[6.6,5.8,5.15,4.6,4.2]),
}
fingers = {name: ([(-x,y,z) for x,y,z in nodes], radii) for name,(nodes,radii) in fingers.items()}
for name,(nodes,rs) in fingers.items():
    digit(name,nodes,rs)

# Radial elongation and pale nail beds aligned to each terminal phalanx.
nails=[]
for name,(nodes,rs) in fingers.items():
    a,b=np.array(nodes[-2]),np.array(nodes[-1])
    t=(b-a)/np.linalg.norm(b-a)
    n=np.array([-.42,-.84,.23]) if name != 'thumb' else np.array([.55,-.54,.20])
    n-=np.dot(n,t)*t
    n/=np.linalg.norm(n)
    u=np.cross(n,t)
    offset=(rs[-1]*.75-.52) if name in ('thumb','index') else (rs[-1]-.65)
    c=.40*a+.60*b+n*offset
    axes=np.asarray([u,n,t])
    radii=(rs[-1]*.73,1.15,rs[-1]*.87)
    ellipsoid(c,radii,axes,k=.45)
    nails.append((c,radii,axes))

# Soft tissue conforms locally to the narrow rounded outside corner of the original
# right jaw's auxiliary trigger near the index knuckle.
relief=np.sqrt(((X+32.8)/5.7)**2+((Y+108.0)/20.0)**2+((Z-106.3)/7.0)**2)-1
field=np.maximum(field,-relief*5.7)
image=vtk.vtkImageData()
image.SetDimensions(len(x),len(y),len(z))
image.SetOrigin(ox,oy,oz)
image.SetSpacing(step,step,step)
image.GetPointData().SetScalars(numpy_to_vtk(field.ravel(order='F'),deep=True))
contour=vtk.vtkFlyingEdges3D()
contour.SetInputData(image)
contour.SetValue(0,0)
clean=vtk.vtkCleanPolyData()
clean.SetInputConnection(contour.GetOutputPort())
normals=vtk.vtkPolyDataNormals()
normals.SetInputConnection(clean.GetOutputPort())
normals.ConsistencyOn()
normals.AutoOrientNormalsOn()
normals.SplittingOff()
normals.Update()
mesh=normals.GetOutput()
boundary=vtk.vtkFeatureEdges()
boundary.SetInputData(mesh)
boundary.FeatureEdgesOff()
boundary.ManifoldEdgesOff()
boundary.BoundaryEdgesOn()
boundary.NonManifoldEdgesOn()
boundary.Update()
assert boundary.GetOutput().GetNumberOfCells()==0
connected=vtk.vtkPolyDataConnectivityFilter()
connected.SetInputData(mesh)
connected.SetExtractionModeToAllRegions()
connected.Update()
assert connected.GetNumberOfExtractedRegions()==1

pts=vtk_to_numpy(mesh.GetPoints().GetData())
color=np.tile(np.array([211,148,117],dtype=np.float32),(len(pts),1))
lightening=np.clip((pts[:,1]+91)/28,-.38,.65)[:,None]
color+=lightening*np.array([23,29,27])
mottle=np.sin(pts[:,0]*.17+pts[:,2]*.06)*np.sin(pts[:,1]*.13-pts[:,2]*.12)
color+=mottle[:,None]*np.array([3.4,2.3,2.])
for c,rs,axes in nails:
    u=(pts-c)@axes.T
    influence=(u[:,0]/rs[0])**2+(u[:,2]/rs[2])**2
    mask=(influence<1.12)&(u[:,1]>-.25)
    alpha=np.clip((1.12-influence[mask])/.37,0,1)[:,None]*.78
    color[mask]=color[mask]*(1-alpha)+np.array([244,183,163])*alpha
rgb=numpy_to_vtk(np.uint8(np.clip(color,0,255)),deep=True)
rgb.SetName('Skin')
mesh.GetPointData().SetScalars(rgb)

for writer,name in [(vtk.vtkPLYWriter(),'Human-Forearm-and-Hand-Pose.ply'),
                    (vtk.vtkSTLWriter(),'Human-Forearm-and-Hand-Pose.stl')]:
    writer.SetFileName(str(support/name))
    writer.SetInputData(mesh)
    writer.SetFileTypeToBinary()
    if hasattr(writer,'SetArrayName'): writer.SetArrayName('Skin')
    assert writer.Write()
print('mesh',mesh.GetNumberOfPoints(),mesh.GetNumberOfCells(),mesh.GetBounds(),flush=True)


