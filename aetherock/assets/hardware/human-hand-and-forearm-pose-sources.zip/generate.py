from pathlib import Path
from collections import Counter
import numpy as np
import vtk
from vtk.util.numpy_support import numpy_to_vtk, vtk_to_numpy

support = Path(__file__).resolve().parent
step = 1.15
ox, oy, oz = -65.,-128.,-288.
x,y,z = [np.arange(a,b,step,dtype=np.float32) for a,b in [(ox,66),(oy,-18),(oz,149)]]
X,Y,Z = np.ix_(x,y,z)
field=np.full((len(x),len(y),len(z)),15,dtype=np.float32)


def union(v,smoothing):
    global field
    if smoothing:
        amount=np.maximum(smoothing-np.abs(field-v),0)/smoothing
        field=np.minimum(field,v)-amount**2*(smoothing*.25)
    else:
        field=np.minimum(field,v)


def ellipsoid(center,radii,axes=None,k=3.5):
    axes=np.eye(3) if axes is None else axes
    D=(X-center[0],Y-center[1],Z-center[2])
    Q=[sum(v*d for v,d in zip(axis,D)) for axis in axes]
    value=np.sqrt(sum((q/r)**2 for q,r in zip(Q,radii)))-1
    union(value*min(radii),k)


def monotone(q, knots):
    points=np.array(knots,float)
    values=points[:,0]
    dx=np.diff(values)
    slope=np.diff(points[:,1:],axis=0)/dx[:,None]
    tang=np.empty_like(points[:,1:])
    tang[0]=slope[0]
    tang[-1]=slope[-1]
    tang[1:-1]=(slope[:-1]+slope[1:])*.5
    blended=[]
    u=np.clip(np.searchsorted(values,q,side='right')-1,0,len(values)-2)
    t=np.clip((q-values[u])/dx[u],0,1)
    for j in range(tang.shape[1]):
        d=dx[u]
        p0=points[u,1+j];p1=points[u+1,1+j]
        m0=tang[u,j];m1=tang[u+1,j]
        blended.append(((2*t-3)*t*t+1)*p0+((t-2)*t+1)*t*m0*d+(-2*t+3)*t*t*p1+(t-1)*t*t*m1*d)
    return blended


knots=[
    (-281,1,-58,1,1,0),(-273,1,-57,30,28,-2),(-248,1,-55,37.3,28.25,-4),
    (-225,0,-52,39.1,28.25,-4),(-201,-.1,-50.9,40.05,28.5,-1),
    (-180,0,-57,34,25,1),(-158,-1,-68,30,23,1),(-138,-1,-72,32,24,2),
    (-111,-1,-73.5,33.5,24,3),(-82,0,-75,31,22.7,6),
    (-55,0,-74.5,28.6,20.1,6),(-44,0,-73.5,27.6,19.7,4),
    (-23,0,-73.5,26.9,19.0,4),(-10,0,-74.8,24.4,18.25,7),
    (5,0,-80,24.5,16.5,9),(20,-1,-83.5,28,14.3,14),
    (36,-1,-84,32.5,15.2,16),(51,-1,-83,34.5,15.5,17),
    (64,-1,-83,32.5,14.0,17),(71,-1,-83,26,11.5,15),
    (79,-1,-83,12,7,13),(83,-1,-83,1,1,13),
]
cx,cy,rx,ry,theta=monotone(z,knots)
rot=theta[None,None,:]*(np.pi/180)
x0=X-cx[None,None,:]
y0=Y-cy[None,None,:]
xp=np.cos(rot)*x0+np.sin(rot)*y0
yp=-np.sin(rot)*x0+np.cos(rot)*y0
base=(np.sqrt((xp/rx[None,None,:])**2+(yp/ry[None,None,:])**2)-1)*np.minimum(rx,ry)[None,None,:]
outside=np.maximum(knots[0][0]-Z,Z-knots[-1][0])
union(np.maximum(base,outside),0)

# Palm contour, thenar and hypothenar pads, metacarpal head and wrist bones.
ellipsoid((-24,-89,39),(15,13,30),k=5.2)
ellipsoid((14,-89.5,38),(16,12.,28),k=6)
ellipsoid((19,-77,54),(13,7.6,18.5),k=4)
ellipsoid((-19,-74,60),(10.0,6.0,10.0),k=3.6)
ellipsoid((22.8,-74.2,-8),(5.0,5.9,8.3),k=3.4)
ellipsoid((-23,-70.5,-4),(4.6,5.2,8.5),k=3)


def segment(p0,p1,r0,r1,k,taper=1.0):
    p=np.asarray(p0)
    d=np.asarray(p1)-p
    t=np.clip(((X-p[0])*d[0]+(Y-p[1])*d[1]+(Z-p[2])*d[2])/np.dot(d,d),0,1)
    dist=np.sqrt((X-p[0]-t*d[0])**2+(Y-p[1]-t*d[1])**2+(Z-p[2]-t*d[2])**2)
    union((dist-r0-(r1-r0)*t)*taper,k)


def digit(nodes,radii):
    for i,(a,b) in enumerate(zip(nodes,nodes[1:])):
        segment(a,b,radii[i],radii[i+1],(2.4,1.55,1.1,1.0)[i])


# Right hand with the dorsal surface toward the cage and fingertips curled under;
# index and thumb open toward the two finger rings, other digits follow naturally.
fingers={
 'index':([(-21,-81,64),(-23,-90,84),(-20,-97.25,105),(-24,-108.7,118),(-26,-117,118)],[9.1,8.8,7.7,6.7,6.3]),
 'middle':([(-6,-81,67),(-5,-83,88),(-5,-92,112),(-7,-108,122),(-7,-119,119)],[8.6,8.25,7.1,6.1,5.6]),
 'ring':([(9,-82.5,67),(10,-87,87),(12,-98,107),(12,-113,112),(12,-121,106)],[8.0,7.5,6.4,5.5,5.0]),
 'little':([(23,-87,62),(25,-92,78),(29,-104,93),(29,-116,95),(27,-121,89)],[7.4,6.65,5.7,4.9,4.6]),
 'thumb':([(20,-89,26),(31,-96,51),(40,-96,74),(42,-100,94),(38,-105,107)],[12,10.1,8.6,7.5,7.0]),
}
for nodes,rs in fingers.values():
    digit(nodes,rs)

# Radial elongation and pale nail beds aligned to each terminal phalanx.
nails=[]
for name,(nodes,rs) in fingers.items():
    a,b=np.array(nodes[-2]),np.array(nodes[-1])
    t=(b-a)/np.linalg.norm(b-a)
    n=np.array([.1,-.28,1.]) if name != 'thumb' else np.array([1,.35,.2])
    n-=np.dot(n,t)*t
    n/=np.linalg.norm(n)
    u=np.cross(n,t)
    c=.40*a+.60*b+n*(rs[-1]-.65)
    axes=np.asarray([u,n,t])
    radii=(rs[-1]*.73,1.15,rs[-1]*.87)
    ellipsoid(c,radii,axes,k=.45)
    nails.append((c,radii,axes))

image=vtk.vtkImageData()
image.SetDimensions(len(x),len(y),len(z))
image.SetOrigin(ox,oy,oz)
image.SetSpacing(step,step,step)
image.GetPointData().SetScalars(numpy_to_vtk(field.ravel(order='F'),deep=True))
contour=vtk.vtkFlyingEdges3D()
contour.SetInputData(image)
contour.SetValue(0,0)
clean=vtk.vtkCleanPolyData()
clean.SetInputConnection(contour.GetOutputPort())
normals=vtk.vtkPolyDataNormals()
normals.SetInputConnection(clean.GetOutputPort())
normals.ConsistencyOn()
normals.AutoOrientNormalsOn()
normals.SplittingOff()
normals.Update()
mesh=normals.GetOutput()
boundary=vtk.vtkFeatureEdges()
boundary.SetInputData(mesh)
boundary.FeatureEdgesOff()
boundary.ManifoldEdgesOff()
boundary.BoundaryEdgesOn()
boundary.NonManifoldEdgesOn()
boundary.Update()
assert boundary.GetOutput().GetNumberOfCells()==0
connected=vtk.vtkPolyDataConnectivityFilter()
connected.SetInputData(mesh)
connected.SetExtractionModeToAllRegions()
connected.Update()
assert connected.GetNumberOfExtractedRegions()==1

pts=vtk_to_numpy(mesh.GetPoints().GetData())
color=np.tile(np.array([211,148,117],dtype=np.float32),(len(pts),1))
lightening=np.clip((pts[:,1]+91)/28,-.38,.65)[:,None]
color+=lightening*np.array([23,29,27])
mottle=np.sin(pts[:,0]*.17+pts[:,2]*.06)*np.sin(pts[:,1]*.13-pts[:,2]*.12)
color+=mottle[:,None]*np.array([3.4,2.3,2.])
for c,rs,axes in nails:
    u=(pts-c)@axes.T
    influence=(u[:,0]/rs[0])**2+(u[:,2]/rs[2])**2
    mask=(influence<1.12)&(u[:,1]>-.25)
    alpha=np.clip((1.12-influence[mask])/.37,0,1)[:,None]*.78
    color[mask]=color[mask]*(1-alpha)+np.array([244,183,163])*alpha
rgb=numpy_to_vtk(np.uint8(np.clip(color,0,255)),deep=True)
rgb.SetName('Skin')
mesh.GetPointData().SetScalars(rgb)

for writer,name in [(vtk.vtkPLYWriter(),'Human-Forearm-and-Hand-Pose.ply'),
                    (vtk.vtkSTLWriter(),'Human-Forearm-and-Hand-Pose.stl')]:
    writer.SetFileName(str(support/name))
    writer.SetInputData(mesh)
    writer.SetFileTypeToBinary()
    if hasattr(writer,'SetArrayName'): writer.SetArrayName('Skin')
    assert writer.Write()
print('mesh',mesh.GetNumberOfPoints(),mesh.GetNumberOfCells(),mesh.GetBounds(),flush=True)


