# AetheRock HandCap

The Parts/ directory contains the individual, English-named STEP parts used in the public CAD release. The project page provides the corresponding assembly STEP. Commercial components use independently modeled exterior geometry for fit review.

The short and rear pivot fastener heads seat in flat-bottom pockets. The short pivots use M2 脳 22 mm low-head screws (脴3.2 脳 0.70 mm heads) and M2 hex nuts. The rear pivots use 脴3 脳 37.55 mm shoulders, M2.5 threads, thrust washers, and M2.5 hex nuts.

Project and assembly downloads
https://lihongcs.github.io/aetherock/

Related upstream hardware

- [GelSlim 4.0 optics and lighting](https://github.com/MMintLab/gelslim_hardware)
- [9DTact camera reference](https://github.com/linchangyi1/9DTact)
- [HTC VIVE Ultimate Tracker](https://www.vive.com/us/accessory/vive-ultimate-tracker/)
- [Hikrobot CB Series cameras](https://www.hikrobotics.com/en/machinevision/visionproduct/?id=80&typeId=78)
- [Orange Pi 4 Pro board support](https://github.com/orangepi-xunlong/orangepi-build#supported-boards)

The included BSD 3-Clause license applies to the CAD authored for this project. Upstream hardware is governed by its source repository's license.

The AS5600 board STEP shows the 90-degree clockwise CN1 connector orientation. The original JLCEDA project retains the prior footprint and copper routing.

Both 22 mm fingertip force films have soldered two-conductor lead routes to the blue voltage conversion modules. These parts model the mechanical routing of a single force channel. The film-tail pin map and matrix readout circuit are pending confirmation.

Both GelSlim Mini fingertips use round 32.84 mm diameter PDMS pads on their acrylic windows.

The control tray carries a FUN-001 large tactile pushbutton module and a 10 mm diffused common-cathode RGB LED module. These STEP parts are mechanical references modeled from prototype photographs. Verify PCB dimensions and installation details against the actual modules. [Pushbutton listing](https://item.taobao.com/item.htm?id=600330037429) · [RGB LED listing](https://item.taobao.com/item.htm?id=659577810824)

The Orange Pi 4 Pro mechanical model follows the [V1.3.2 board drawing](https://drive.google.com/file/d/1Y0IVGWaeSwKd_PaWXpa6HuQZ4deNgu57/view) and prototype photos. It includes the board outline, mounting holes, visible components and recessed connector openings.

Two blue-and-white 5-position XH2.54 ribbon cables connect the U5 force ADC headers to U2 and U3 on the Orange Pi GPIO interconnect. Both front looms pass through the existing side openings, then the cables run inside the frame to the shared black braided sleeve. The earlier adaptive gripper STEP uses the prior adapter revision. [XH2.54 cable listing](https://item.taobao.com/item.htm?id=607731675302)

The four-position AS5600 encoder ribbon connects CN1 on the encoder daughterboard to CN1 on the Orange Pi GPIO interconnect. It shares the braided sleeve with the force sensor ribbons and leaves a flexible section at the moving encoder mount.

The three-position pushbutton ribbon plugs into CN2 on the GPIO interconnect, and the four-position RGB LED ribbon plugs into CN3. Each ribbon terminates in individually soldered wires at the control module.
