# AetheRock HandCap

This archive contains editable SolidWorks part files authored for this project. The published assembly STEP includes the full public assembly and modeled exteriors for the vendor components. The SolidWorks part files are grouped under Parts/.

The short and rear pivot fastener heads seat in flat-bottom pockets. The short pivots use M2 脳 22 mm low-head screws (脴3.2 脳 0.70 mm heads) and M2 hex nuts. The rear pivots use 脴3 脳 37.55 mm shoulders, M2.5 threads, thrust washers, and M2.5 hex nuts.

Project and assembly downloads
https://lihongcs.github.io/aetherock/

Related upstream hardware

- [GelSlim 4.0 optics and lighting](https://github.com/MMintLab/gelslim_hardware)
- [9DTact camera reference](https://github.com/linchangyi1/9DTact)
- [HTC VIVE Ultimate Tracker](https://www.vive.com/us/accessory/vive-ultimate-tracker/)
- [Hikrobot CB Series cameras](https://www.hikrobotics.com/en/machinevision/visionproduct/?id=80&typeId=78)
- [Orange Pi 4 Pro board support](https://github.com/orangepi-xunlong/orangepi-build#supported-boards)

The included BSD 3-Clause license applies to the CAD authored for this project. Upstream hardware is governed by its source repository's license.
