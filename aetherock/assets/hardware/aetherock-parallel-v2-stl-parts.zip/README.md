# AetheRock Parallel Gripper V2

The V2 placement uses the native assembly and parts in v2_new_camera. The STL geometry uses millimetres.

The assembly STL contains positioned components for inspection and fit reference. Its components can have intentional contacts and overlaps. Individual parts are in Parts/ in their own local coordinate systems. Use the named structural parts for fabrication. The package may also include part geometry for components such as optical surfaces, circuit boards or fasteners.

The fitted jaw and trigger parts include 0.10 mm relief along the modeled 7 × 5 mm rail sweep and local clearance for the GelSlim optical shrouds. The tactile back covers clear the native jaw material and make room for the OV5647 optics. The fitted frame clears the VIVE quick-release bracket. The original SolidWorks files preserve the starting geometry for these parts.

Purchased camera electronics and the VIVE tracker are mechanical fit references. The assembly uses independently modeled exteriors for those components. They are listed below and have no individual files in this package. The BSD 3-Clause license applies to project-authored files.

- Hikrobot MV CB060 Camera (1)
- Left OV5647 Camera FPC (1)
- Left OV5647 Fisheye Camera (1)
- Left OV5647 USB Adapter PCB (1)
- Right OV5647 Camera FPC (1)
- Right OV5647 Fisheye Camera (1)
- Right OV5647 USB Adapter PCB (1)
- VIVE Ultimate Tracker (1)
