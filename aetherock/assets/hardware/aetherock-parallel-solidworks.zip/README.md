# AetheRock Parallel Gripper SolidWorks Parts

The original parallel design uses the revised Hikrobot camera mount. Fitted parts in SolidWorks/ contain editable solid bodies imported from the release geometry. Numbered bodies share the same part origin. Other parts retain their native feature history. The Original/ folder contains the original part documents used to create the fitted bodies.

Use the assembled STL and web model to inspect placements, including the paired GelSlim Mini optical stacks, force sensing electronics and controller wiring. The wiring represents physical routing. Reading individual elements of the force matrix requires a compatible readout circuit.
