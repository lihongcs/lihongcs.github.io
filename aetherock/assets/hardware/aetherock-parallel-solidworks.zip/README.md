# AetheRock Parallel Gripper SolidWorks Parts

The original parallel design uses the revised Hikrobot camera mount. Fitted parts in SolidWorks/ contain editable solid bodies imported from the release geometry. Numbered bodies share the same part origin. Other parts retain their native feature history. The Original/ folder contains the original part documents used to create the fitted bodies.

The two reconstructed drive links have a 44 mm pivot-center distance. The frame includes clearance for the rotor and right carriage over a 0 to 100 mm tactile-pad opening. The fitted bodies have been checked in CAD.

Use the assembled STL and web model to inspect placements, including the paired GelSlim Mini optical stacks, force sensing electronics and controller wiring. The wiring represents physical routing. Reading individual elements of the force matrix requires a compatible readout circuit.
